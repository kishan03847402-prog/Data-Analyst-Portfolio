# Data Analyst Portfolio

Seven end-to-end analytics projects. Each one follows the same workflow a working analyst uses: **validate the data, clean what is fixable, analyse, test whether the pattern is real, and recommend action** (with the limits stated).

| # | Project | Headline result | Core stack |
|---|---------|-----------------|------------|
| 1 | [Sales Dashboard](01-sales-dashboard) | 32.3% margin; revenue driven by order volume, not basket size; Phone/Monitor weakest margins | Python (pandas |
| 2 | [Superstore Profitability](02-superstore-analysis) | 16% of orders lose money; discounts show **no** significant margin effect (rho -0.02, p 0.66); Bookcase is the weak spot | Python (pandas |
| 3 | [Netflix Catalogue EDA](03-netflix-analysis) | Movies 46% / TV 54%; catalogue skews old (median title 16 years); 54% of rows fail the type/duration check | Python (pandas |
| 4 | [HR Attrition](04-hr-attrition-analysis) | 17.3% attrition; only age shows a significant signal; no department/pay effect beyond noise | Python (pandas |
| 5 | [IPL Analytics](05-ipl-analysis) | Only 24 of 120 matches pass integrity checks; toss impact untestable; phase analysis on 1,052 clean balls | Python (pandas |
| 6 | [COVID Dashboard (synthetic)](06-covid-dashboard) | Synthetic data: 16 impossible positivity records caught; no structure, so no real conclusions | Python (pandas |
| 7 | [E-Commerce & RFM](07-ecommerce-analysis) | 18.9% of order value lost to cancel/return; Loyal+Champions = 54% of revenue; 14 high-value customers at risk | Python (pandas |

## Honest note about the data
All eight source files are **demo / synthetic datasets**. They contain real-world-style problems on purpose or by accident (winners who did not play, employees who joined before age 18, movies with "Seasons"). Instead of hiding that, every project starts with a **data quality audit** and reports only what survives it. Numbers describe the demo files, not any real company, league or pandemic. Because every pipeline is schema-compatible, you can swap in a real dataset and regenerate every chart, table and README number.

## What this portfolio demonstrates
- **Data cleaning and validation**: rule-based audits with counts and actions (`output/data_quality_audit.csv` in every project)
- **Python**: pandas, numpy, matplotlib, seaborn, scipy
- **Statistics**: confidence intervals (Wilson), chi-square, Mann-Whitney, Spearman, binomial test; calling out small samples
- **SQL**: tested queries with window functions (LAG, RANK, ROW_NUMBER, moving averages), CTEs, conditional aggregation
- **Business analytics**: KPI design, profitability, funnel/leakage, RFM segmentation, attrition analysis
- **BI-ready outputs**: summary CSVs for Power BI / Tableau in each `output/` folder

## Quick start
```bash
git clone https://github.com/kishan03847402-prog/data-analyst-portfolio.git
cd data-analyst-portfolio
pip install -r requirements.txt
python run_all.py          # rebuilds every project: clean data, charts, summaries, SQL results
```

## Repository layout
```
common.py            shared helpers (audit log, plotting style, SQL runner)
run_all.py           runs all 7 projects
docs/                cross-project data quality report
01-... to 07-...     one folder per project (README, analysis.py, sql/, data/, images/, output/)
```

## Data quality summary
See [docs/data_quality_report.md](docs/data_quality_report.md).

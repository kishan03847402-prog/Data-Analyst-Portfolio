"""Project 5 - IPL: toss impact, team performance, phase-wise batting/bowling from ball-by-ball data.
Input: data/raw/05_IPL_Matches_Demo.csv, data/raw/05_IPL_Ball_by_Ball_Demo.csv
Because the raw data has serious integrity problems, the audit section matters as much as the analysis."""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from common import *
from scipy import stats

here = setup(__file__)
m = pd.read_csv(here / "data/raw/05_IPL_Matches_Demo.csv", parse_dates=["Date"])
b = pd.read_csv(here / "data/raw/05_IPL_Ball_by_Ball_Demo.csv")
a = Audit(here, len(m))
a.check("Duplicate MatchID", m.MatchID.duplicated(), "none found")
in_teams_w = m.apply(lambda r: r.Winner in (r.Team1, r.Team2), axis=1)
in_teams_t = m.apply(lambda r: r.TossWinner in (r.Team1, r.Team2), axis=1)
a.check("Winner is not one of the two teams playing", ~in_teams_w, "excluded from win/loss and toss analysis")
a.check("TossWinner is not one of the two teams playing", ~in_teams_t, "excluded from toss analysis")
a.check("Date year != Season", m.Date.dt.year != m.Season, "Season column treated as unreliable; season-wise trends NOT reported")
m["ValidResult"] = in_teams_w; m["ValidToss"] = in_teams_t & in_teams_w
a.save()
ab = Audit(here, len(b))
dup = b.duplicated(["MatchID", "Innings", "Over", "Ball"], keep="first")
same = b.BattingTeam == b.BowlingTeam
ab.check("Duplicate ball (same match, innings, over, ball)", dup, "dropped (kept first)")
ab.check("BattingTeam == BowlingTeam", same, "dropped")
ab.check("MatchID not in matches table", ~b.MatchID.isin(m.MatchID), "none found")
b2 = b[~dup & ~same].copy()
ab.check("Sample covers only part of each match (1200 rows / 120 matches = ~10 balls per match)", len(b2), "ball-by-ball is a SAMPLE: used for rates (per ball), never for match totals")
pd.DataFrame(ab.rows).to_csv(here / "output/data_quality_audit_ball_by_ball.csv", index=False); print(pd.DataFrame(ab.rows).to_string(index=False))
m.to_csv(here / "data/clean/ipl_matches_clean.csv", index=False)

# ---------- matches
v = m[m.ValidResult].copy(); vt = m[m.ValidToss].copy()
vt["TossWinnerWon"] = vt.TossWinner == vt.Winner
toss_rate = vt.TossWinnerWon.mean() * 100
bt = stats.binomtest(int(vt.TossWinnerWon.sum()), len(vt), 0.5)
lo_ci, hi_ci = bt.proportion_ci(confidence_level=.95)
teams = pd.concat([m.Team1, m.Team2]).value_counts().rename("Played")
vteams = pd.concat([v.Team1, v.Team2]).value_counts().rename("Played")
wins = v.Winner.value_counts().rename("Wins")
tw = pd.concat([vteams, wins], axis=1).fillna(0); tw["Win%"] = tw.Wins / tw.Played * 100
tw = tw.sort_values("Win%", ascending=False)
venue = pd.concat([v.assign(Team=v.Team1), v.assign(Team=v.Team2)])
vw = v.groupby("Venue").size().rename("Matches")
decision = v.groupby("WinType").Margin.agg(["count", "median", "mean"]); decision["share%"] = decision["count"] / len(v) * 100
tw.round(1).to_csv(here / "output/team_win_rates.csv"); decision.round(1).to_csv(here / "output/win_type_margin.csv")

# ---------- ball by ball (rates only)
b2["Phase"] = pd.cut(b2.Over, [-1, 5, 14, 19], labels=["Powerplay (1-6)", "Middle (7-15)", "Death (16-20)"])
b2["TotalRuns"] = b2.BatterRuns + b2.ExtraRuns
b2["IsWicket"] = (b2.Wicket == "Yes").astype(int)
ph = b2.groupby("Phase", observed=True).agg(Balls=("TotalRuns", "size"), RunsPerBall=("TotalRuns", "mean"), WicketRate=("IsWicket", "mean"), Extras=("ExtraRuns", "mean"))
ph["RunRate(per over)"] = ph.RunsPerBall * 6; ph["Wicket%"] = ph.WicketRate * 100; ph["Balls per wicket"] = 1 / ph.WicketRate
bat = b2.groupby("Batter").agg(Balls=("BatterRuns", "size"), Runs=("BatterRuns", "sum"), Fours=("BatterRuns", lambda s: (s == 4).sum()), Sixes=("BatterRuns", lambda s: (s == 6).sum()), Dismissals=("IsWicket", "sum"))
bat["StrikeRate"] = bat.Runs / bat.Balls * 100; bat["Boundary%"] = (bat.Fours + bat.Sixes) / bat.Balls * 100
bowl = b2.groupby("Bowler").agg(Balls=("TotalRuns", "size"), Runs=("TotalRuns", "sum"), Wickets=("IsWicket", "sum")); bowl["Economy"] = bowl.Runs / bowl.Balls * 6
bat.round(1).to_csv(here / "output/batter_rates.csv"); bowl.round(2).to_csv(here / "output/bowler_rates.csv"); ph.round(3).to_csv(here / "output/phase_summary.csv")
inn = b2.groupby("Innings").agg(RPB=("TotalRuns", "mean"), W=("IsWicket", "mean")); 
dot = (b2.TotalRuns == 0).mean() * 100; boundary = (b2.BatterRuns >= 4).mean() * 100
p_phase = stats.chi2_contingency(pd.crosstab(b2.Phase, b2.IsWicket))[1]
F = dict(matches=len(m), valid_result_matches=int(m.ValidResult.sum()), valid_toss_matches=int(m.ValidToss.sum()),
         toss_winner_won_pct=toss_rate, toss_ci_low=lo_ci * 100, toss_ci_high=hi_ci * 100, toss_p=bt.pvalue,
         best_team=tw.index[0], best_team_win=tw["Win%"].iloc[0], best_team_played=int(tw.Played.iloc[0]), worst_team=tw.index[-1], worst_team_win=tw["Win%"].iloc[-1], worst_team_played=int(tw.Played.iloc[-1]),
         most_wins_team=tw.Wins.idxmax(), most_wins=int(tw.Wins.max()),
         runs_win_share=decision.loc["Runs", "share%"], wickets_win_share=decision.loc["Wickets", "share%"],
         median_run_margin=decision.loc["Runs", "median"], median_wicket_margin=decision.loc["Wickets", "median"],
         venue_most_matches=vw.idxmax(), venue_most_matches_n=int(vw.max()),
         balls_used=len(b2), balls_dropped=int(len(b) - len(b2)),
         phase_rpo={str(k): round(x, 2) for k, x in ph["RunRate(per over)"].items()}, phase_wicket_pct={str(k): round(x, 1) for k, x in ph["Wicket%"].items()}, phase_p=p_phase,
         overall_rpo=b2.TotalRuns.mean() * 6, overall_wicket_pct=b2.IsWicket.mean() * 100, dot_ball_pct=dot, boundary_pct=boundary,
         best_sr_batter=bat.StrikeRate.idxmax(), best_sr=bat.StrikeRate.max(), best_economy_bowler=bowl.Economy.idxmin(), best_economy=bowl.Economy.min(), most_wkts_bowler=bowl.Wickets.idxmax(), most_wkts=int(bowl.Wickets.max()))
save_findings(here, F)

fig = plt.figure(figsize=(16, 10.5)); gs = fig.add_gridspec(2, 3, top=0.88, hspace=0.42, wspace=0.3)
header(fig, "IPL Analysis (Demo Dataset, validated)", {"Matches": len(m), "Valid results": int(m.ValidResult.sum()), "Valid toss records": int(m.ValidToss.sum()), "Clean balls": len(b2)})
ax = fig.add_subplot(gs[0, 0]); fun = pd.Series({"All matches": len(m), "Winner is a\nplaying team": int(m.ValidResult.sum()), "...and toss winner\nis a playing team": int(m.ValidToss.sum())})
ax.barh(fun.index[::-1], fun.values[::-1], color=[RED, ORANGE, BLUE]); ax.set_title("Data Validity Funnel (matches)"); [ax.text(v + 1, i, str(v), va="center") for i, v in enumerate(fun.values[::-1])]; ax.set_xlim(0, 140)
ax.text(.5, -.18, f"Toss impact cannot be tested: only {int(m.ValidToss.sum())} match has a valid toss record", transform=ax.transAxes, ha="center", fontsize=9, color=RED)
ax = fig.add_subplot(gs[0, 1:]); tw["Win%"].sort_values().plot.barh(ax=ax, color=BLUE); ax.set_title(f"Team Win % (only {len(v)} matches with a valid result; indicative, small n)")
for i, (t, r) in enumerate(tw["Win%"].sort_values().items()): ax.text(r + .5, i, f"{r:.0f}%  ({int(tw.Played[t])} played)", va="center", fontsize=9)
ax.axvline(50, color=RED, ls="--", lw=1); ax.set_xlim(0, 85)
ax = fig.add_subplot(gs[1, 0]); ph["RunRate(per over)"].plot.bar(ax=ax, color=ORANGE, rot=0); ax.set_title("Run Rate by Phase (runs/over)"); bar_labels(ax, "{:.1f}"); ax.set_xlabel("")
ax = fig.add_subplot(gs[1, 1]); ph["Wicket%"].plot.bar(ax=ax, color=RED, rot=0); ax.set_title("Wicket % of Balls by Phase"); bar_labels(ax, "{:.1f}"); ax.set_xlabel("")
ax = fig.add_subplot(gs[1, 2]); bat.StrikeRate.sort_values().plot.barh(ax=ax, color=PURPLE); ax.set_title("Batter Strike Rate (sample)"); bar_labels(ax, "{:.0f}")
plt.savefig(here / "images/ipl_dashboard.png", dpi=150, bbox_inches="tight"); plt.close()
run_sql(here, {"matches": m.drop(columns=[]), "balls": b2.drop(columns=["Phase"])})
print("\nFINDINGS"); [print(f"  {k}: {v}") for k, v in F.items()]; print(tw.round(1)); print(ph.round(2)); print(decision.round(1)); print(bat.round(1)); print(bowl.round(2))

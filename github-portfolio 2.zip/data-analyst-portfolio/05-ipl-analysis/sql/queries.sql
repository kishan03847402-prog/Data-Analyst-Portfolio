-- name: 1. Toss winner vs match winner (valid rows only)
SELECT COUNT(*) AS matches, SUM(CASE WHEN TossWinner = Winner THEN 1 ELSE 0 END) AS toss_winner_won,
       ROUND(100.0*SUM(CASE WHEN TossWinner = Winner THEN 1 ELSE 0 END)/COUNT(*),1) AS toss_win_pct
FROM matches WHERE ValidToss = 1;

-- name: 2. Team win percentage (valid results)
WITH played AS (
  SELECT Team1 AS team, Winner FROM matches WHERE ValidResult = 1
  UNION ALL SELECT Team2, Winner FROM matches WHERE ValidResult = 1)
SELECT team, COUNT(*) AS played, SUM(CASE WHEN team = Winner THEN 1 ELSE 0 END) AS wins,
       ROUND(100.0*SUM(CASE WHEN team = Winner THEN 1 ELSE 0 END)/COUNT(*),1) AS win_pct
FROM played GROUP BY team ORDER BY win_pct DESC;

-- name: 3. Run rate and wicket rate by phase of the innings
SELECT CASE WHEN Over <= 5 THEN '1 Powerplay' WHEN Over <= 14 THEN '2 Middle' ELSE '3 Death' END AS phase,
       COUNT(*) AS balls, ROUND(6.0*AVG(BatterRuns+ExtraRuns),2) AS runs_per_over,
       ROUND(100.0*AVG(CASE WHEN Wicket='Yes' THEN 1 ELSE 0 END),1) AS wicket_pct
FROM balls GROUP BY 1 ORDER BY 1;

-- name: 4. Bowler economy and wickets
SELECT Bowler, COUNT(*) AS balls, SUM(CASE WHEN Wicket='Yes' THEN 1 ELSE 0 END) AS wickets,
       ROUND(6.0*SUM(BatterRuns+ExtraRuns)/COUNT(*),2) AS economy
FROM balls GROUP BY Bowler ORDER BY economy;

### 1. Toss winner vs match winner (valid rows only)

```sql
SELECT COUNT(*) AS matches, SUM(CASE WHEN TossWinner = Winner THEN 1 ELSE 0 END) AS toss_winner_won,
       ROUND(100.0*SUM(CASE WHEN TossWinner = Winner THEN 1 ELSE 0 END)/COUNT(*),1) AS toss_win_pct
FROM matches WHERE ValidToss = 1;
```

|   matches |   toss_winner_won |   toss_win_pct |
|----------:|------------------:|---------------:|
|         1 |                 1 |            100 |

### 2. Team win percentage (valid results)

```sql
WITH played AS (
  SELECT Team1 AS team, Winner FROM matches WHERE ValidResult = 1
  UNION ALL SELECT Team2, Winner FROM matches WHERE ValidResult = 1)
SELECT team, COUNT(*) AS played, SUM(CASE WHEN team = Winner THEN 1 ELSE 0 END) AS wins,
       ROUND(100.0*SUM(CASE WHEN team = Winner THEN 1 ELSE 0 END)/COUNT(*),1) AS win_pct
FROM played GROUP BY team ORDER BY win_pct DESC;
```

| team   |   played |   wins |   win_pct |
|:-------|---------:|-------:|----------:|
| MI     |        5 |      4 |      80   |
| LSG    |        5 |      4 |      80   |
| SRH    |        4 |      3 |      75   |
| GT     |        5 |      3 |      60   |
| KKR    |        6 |      3 |      50   |
| RR     |        7 |      3 |      42.9 |
| PBKS   |        3 |      1 |      33.3 |
| RCB    |        4 |      1 |      25   |
| DC     |        4 |      1 |      25   |
| CSK    |        5 |      1 |      20   |

### 3. Run rate and wicket rate by phase of the innings

```sql
SELECT CASE WHEN Over <= 5 THEN '1 Powerplay' WHEN Over <= 14 THEN '2 Middle' ELSE '3 Death' END AS phase,
       COUNT(*) AS balls, ROUND(6.0*AVG(BatterRuns+ExtraRuns),2) AS runs_per_over,
       ROUND(100.0*AVG(CASE WHEN Wicket='Yes' THEN 1 ELSE 0 END),1) AS wicket_pct
FROM balls GROUP BY 1 ORDER BY 1;
```

| phase       |   balls |   runs_per_over |   wicket_pct |
|:------------|--------:|----------------:|-------------:|
| 1 Powerplay |     316 |           14.62 |         19.3 |
| 2 Middle    |     481 |           14.71 |         21   |
| 3 Death     |     255 |           13.6  |         21.6 |

### 4. Bowler economy and wickets

```sql
SELECT Bowler, COUNT(*) AS balls, SUM(CASE WHEN Wicket='Yes' THEN 1 ELSE 0 END) AS wickets,
       ROUND(6.0*SUM(BatterRuns+ExtraRuns)/COUNT(*),2) AS economy
FROM balls GROUP BY Bowler ORDER BY economy;
```

| Bowler   |   balls |   wickets |   economy |
|:---------|--------:|----------:|----------:|
| Player K |     199 |        40 |     13.24 |
| Player H |     203 |        36 |     14.19 |
| Player I |     210 |        42 |     14.4  |
| Player J |     213 |        53 |     14.96 |
| Player G |     227 |        46 |     15.15 |

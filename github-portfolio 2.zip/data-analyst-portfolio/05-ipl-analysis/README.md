# IPL Analytics: Data Validation, Team and Phase Analysis

Does the toss matter, and how do batting and bowling change across the innings? First, can the data be trusted?

> **Dataset note:** this project uses a *demo / synthetic* dataset supplied for portfolio practice. All numbers below describe that file, not a real company or event. The code is schema-compatible: drop a real CSV with the same columns into `data/raw/` and re-run.

![dashboard](images/ipl_dashboard.png)

## Problem statement
An analyst is handed match and ball-by-ball data and asked about toss impact, team strength and phase-wise scoring.

## Dataset
| | |
|---|---|
| File | `data/raw/05_IPL_Matches_Demo.csv + 05_IPL_Ball_by_Ball_Demo.csv` |
| Size | 120 matches, 1,200 balls rows |
| Period | 2018-2025 (per Date column) |
| Columns | Matches: MatchID, Season, Date, Team1, Team2, Venue, TossWinner, Winner, WinType, Margin | Balls: MatchID, Innings, Over, Ball, BattingTeam, BowlingTeam, Batter, Bowler, BatterRuns, ExtraRuns, Wicket |

## Business questions
- Does winning the toss improve the chance of winning the match?
- Which teams win most?
- How do run rate and wicket rate change across powerplay, middle and death overs?

## Approach
1. Wrote integrity rules (winner and toss winner must be one of the two teams; date year must equal season; no duplicate balls; batting team != bowling team).
2. Used only rows that pass the rules; reported how many survive.
3. Computed phase metrics per ball, since ball-by-ball is a sample, plus a chi-square test across phases.

## Data quality audit
Every check is run by `analysis.py` and saved to `output/data_quality_audit.csv`.

| Check                                          |   Rows affected |   % of rows | Action taken                                                         |
|:-----------------------------------------------|----------------:|------------:|:---------------------------------------------------------------------|
| Duplicate MatchID                              |               0 |         0   | none found                                                           |
| Winner is not one of the two teams playing     |              96 |        80   | excluded from win/loss and toss analysis                             |
| TossWinner is not one of the two teams playing |             102 |        85   | excluded from toss analysis                                          |
| Date year != Season                            |             105 |        87.5 | Season column treated as unreliable; season-wise trends NOT reported |

**Ball-by-ball file:**

| Check                                                                                 |   Rows affected |   % of rows | Action taken                                                                |
|:--------------------------------------------------------------------------------------|----------------:|------------:|:----------------------------------------------------------------------------|
| Duplicate ball (same match, innings, over, ball)                                      |              31 |         2.6 | dropped (kept first)                                                        |
| BattingTeam == BowlingTeam                                                            |             120 |        10   | dropped                                                                     |
| MatchID not in matches table                                                          |               0 |         0   | none found                                                                  |
| Sample covers only part of each match (1200 rows / 120 matches = ~10 balls per match) |            1052 |        87.7 | ball-by-ball is a SAMPLE: used for rates (per ball), never for match totals |

## Key findings
1. Data audit: only 24 of 120 matches (20%) have a winner that is actually one of the two teams, and only 1 match has a valid toss record. The toss question cannot be answered from this file.
2. In the 24 usable matches, MI and LSG won 4 of 5 and CSK 1 of 5, but with 3-7 matches per team this is indicative only. Wins by runs: 54% (median margin 36); by wickets: 46% (median 17).
3. After removing 148 duplicate or impossible balls, 1,052 remain (about 9 per match). Run rate: powerplay 14.6, middle 14.7, death 13.6 runs/over; wicket rate 19.3% / 21.0% / 21.6% of balls. The phase difference is not significant (p = 0.77).
4. 23% of balls are dots and 22% boundaries. Among sampled players, Player D has the highest strike rate (218), Player K the best economy (13.2) and Player J the most wickets (53).

## Recommendations
1. Add the integrity rules above as automated checks at data load: 80% of match rows fail the winner check.
2. Source the full public IPL match and ball-by-ball files and re-run: the pipeline is schema-compatible, so only the CSVs change.
3. Only then answer the toss question, with a binomial test and confidence interval (already coded).

## Limitations
- Run rate around 14 per over and a wicket on 21% of balls are not realistic for cricket: another sign this is synthetic data.
- Batters and bowlers are anonymised (Player A-K).
- Ball-by-ball rows are a sample, so match totals and partnerships are not computed.

## SQL
`sql/queries.sql` re-computes the key metrics in SQL (SQLite syntax, window functions). `analysis.py` executes them and writes the results to [`output/sql_results.md`](output/sql_results.md), so the SQL is tested, not just written.

## Tools
Python (pandas, scipy, matplotlib, seaborn), SQLite (window functions)

## How to run
```bash
pip install -r ../requirements.txt
python analysis.py
```
Creates `data/clean/`, `images/`, `output/` (summary CSVs for Power BI / Tableau, `findings.json`, `sql_results.md`).

## Project structure
```
data/raw/     input CSV(s), unchanged
data/clean/   validated data with derived columns
sql/          queries.sql
images/       dashboard PNG
output/       summary CSVs, data_quality_audit.csv, findings.json, sql_results.md
analysis.py   validation, analysis, charts, SQL run
```

# Data Quality Report (all projects)

Generated from each project's `output/data_quality_audit.csv`. Only checks that found a problem are shown.


## Sales Dashboard

| Check                                                   |   Rows affected |   % of rows | Action taken                                       |
|:--------------------------------------------------------|----------------:|------------:|:---------------------------------------------------|
| Products sold at >1 unit price (price varies per order) |               8 |         2.7 | kept; analysed at product level, not by price list |

## Superstore Profitability

No issues found.

## Netflix Catalogue EDA

| Check                                                           |   Rows affected |   % of rows | Action taken                                                                                  |
|:----------------------------------------------------------------|----------------:|------------:|:----------------------------------------------------------------------------------------------|
| Repeated Title (same title, different ShowID/attributes)        |             172 |        95.6 | kept - ShowID is the key; titles reused in this demo data, so title-level counts are NOT used |
| Type/Duration conflict (Movie in 'Seasons' or TV Show in 'min') |              98 |        54.4 | flagged; excluded ONLY from duration analysis                                                 |
| Added to Netflix before its release year                        |               1 |         0.6 | kept; excluded from 'content age' calc                                                        |

## HR Attrition

| Check                                                      |   Rows affected |   % of rows | Action taken                                |
|:-----------------------------------------------------------|----------------:|------------:|:--------------------------------------------|
| YearsAtCompany > Age-18 (joined before age 18: impossible) |              54 |        24.5 | flagged; excluded ONLY from tenure analysis |

## IPL Analytics

| Check                                          |   Rows affected |   % of rows | Action taken                                                         |
|:-----------------------------------------------|----------------:|------------:|:---------------------------------------------------------------------|
| Winner is not one of the two teams playing     |              96 |        80   | excluded from win/loss and toss analysis                             |
| TossWinner is not one of the two teams playing |             102 |        85   | excluded from toss analysis                                          |
| Date year != Season                            |             105 |        87.5 | Season column treated as unreliable; season-wise trends NOT reported |

Ball-by-ball file:

| Check                                                                                 |   Rows affected |   % of rows | Action taken                                                                |
|:--------------------------------------------------------------------------------------|----------------:|------------:|:----------------------------------------------------------------------------|
| Duplicate ball (same match, innings, over, ball)                                      |              31 |         2.6 | dropped (kept first)                                                        |
| BattingTeam == BowlingTeam                                                            |             120 |        10   | dropped                                                                     |
| Sample covers only part of each match (1200 rows / 120 matches = ~10 balls per match) |            1052 |        87.7 | ball-by-ball is a SAMPLE: used for rates (per ball), never for match totals |

## COVID Dashboard (synthetic)

| Check                                                                  |   Rows affected |   % of rows | Action taken                                                |
|:-----------------------------------------------------------------------|----------------:|------------:|:------------------------------------------------------------|
| Duplicate (Date, Country)                                              |               2 |         0.8 | dropped duplicates (kept first)                             |
| NewDeaths > NewCases (impossible)                                      |               4 |         1.7 | excluded from fatality-rate analysis                        |
| NewCases > Tests (positivity > 100%, impossible)                       |              16 |         6.7 | excluded from positivity analysis                           |
| Sparse sampling: ~7 rows per month across 8 countries (not daily data) |             238 |        99.2 | no daily rolling averages; analysis uses monthly aggregates |

## E-Commerce & RFM

| Check                                                                |   Rows affected |   % of rows | Action taken                                                                |
|:---------------------------------------------------------------------|----------------:|------------:|:----------------------------------------------------------------------------|
| Same product sold under >1 category                                  |             350 |         100 | kept; Category column unreliable, so category analysis uses Product instead |
| Same product with extreme price spread (min vs max unit price > 10x) |             350 |         100 | kept; revenue analysed, price-point conclusions avoided                     |

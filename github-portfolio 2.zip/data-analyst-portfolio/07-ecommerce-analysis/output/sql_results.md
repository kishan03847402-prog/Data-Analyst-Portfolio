### 1. Revenue: gross vs net (delivered only)

```sql
SELECT ROUND(SUM(TotalAmount),0) AS gross_revenue, ROUND(SUM(CASE WHEN OrderStatus='Delivered' THEN TotalAmount END),0) AS net_delivered_revenue,
       ROUND(100.0*SUM(IsLost)/COUNT(*),1) AS cancel_return_pct FROM orders;
```

|   gross_revenue |   net_delivered_revenue |   cancel_return_pct |
|----------------:|------------------------:|--------------------:|
|     2.59168e+06 |                1.76e+06 |                  18 |

### 2. Cancel + return rate by payment method

```sql
SELECT PaymentMethod, COUNT(*) AS orders, SUM(IsLost) AS cancelled_or_returned, ROUND(100.0*SUM(IsLost)/COUNT(*),1) AS loss_rate_pct
FROM orders GROUP BY PaymentMethod ORDER BY loss_rate_pct DESC;
```

| PaymentMethod    |   orders |   cancelled_or_returned |   loss_rate_pct |
|:-----------------|---------:|------------------------:|----------------:|
| UPI              |       70 |                      15 |            21.4 |
| Cash on Delivery |       64 |                      13 |            20.3 |
| Credit Card      |       80 |                      14 |            17.5 |
| Debit Card       |       65 |                      11 |            16.9 |
| Net Banking      |       71 |                      10 |            14.1 |

### 3. Net revenue by city with share

```sql
SELECT City, ROUND(SUM(TotalAmount),0) AS net_revenue,
       ROUND(100.0*SUM(TotalAmount)/(SELECT SUM(TotalAmount) FROM orders WHERE OrderStatus='Delivered'),1) AS share_pct
FROM orders WHERE OrderStatus='Delivered' GROUP BY City ORDER BY net_revenue DESC;
```

| City      |   net_revenue |   share_pct |
|:----------|--------------:|------------:|
| Delhi     |        316580 |        18   |
| Bengaluru |        303985 |        17.3 |
| Pune      |        282056 |        16   |
| Jaipur    |        269260 |        15.3 |
| Mumbai    |        225942 |        12.8 |
| Kolkata   |        214116 |        12.2 |
| Patna     |        148062 |         8.4 |

### 4. Simple RFM base table (delivered orders)

```sql
SELECT CustomerID, CAST(julianday((SELECT MAX(OrderDate) FROM orders WHERE OrderStatus='Delivered')) - julianday(MAX(OrderDate)) AS INT) AS recency_days,
       COUNT(*) AS frequency, SUM(TotalAmount) AS monetary
FROM orders WHERE OrderStatus='Delivered' GROUP BY CustomerID ORDER BY monetary DESC LIMIT 10;
```

| CustomerID   |   recency_days |   frequency |   monetary |
|:-------------|---------------:|------------:|-----------:|
| CU1212       |             14 |           2 |      43144 |
| CU1109       |             61 |           2 |      34992 |
| CU1127       |             86 |           3 |      32965 |
| CU1066       |             24 |           4 |      32628 |
| CU1019       |             54 |           3 |      32466 |
| CU1141       |             95 |           5 |      31224 |
| CU1151       |             29 |           2 |      30238 |
| CU1106       |             12 |           3 |      30234 |
| CU1048       |              1 |           3 |      30040 |
| CU1060       |              6 |           3 |      28606 |

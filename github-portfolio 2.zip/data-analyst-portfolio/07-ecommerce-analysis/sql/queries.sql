-- name: 1. Revenue: gross vs net (delivered only)
SELECT ROUND(SUM(TotalAmount),0) AS gross_revenue, ROUND(SUM(CASE WHEN OrderStatus='Delivered' THEN TotalAmount END),0) AS net_delivered_revenue,
       ROUND(100.0*SUM(IsLost)/COUNT(*),1) AS cancel_return_pct FROM orders;

-- name: 2. Cancel + return rate by payment method
SELECT PaymentMethod, COUNT(*) AS orders, SUM(IsLost) AS cancelled_or_returned, ROUND(100.0*SUM(IsLost)/COUNT(*),1) AS loss_rate_pct
FROM orders GROUP BY PaymentMethod ORDER BY loss_rate_pct DESC;

-- name: 3. Net revenue by city with share
SELECT City, ROUND(SUM(TotalAmount),0) AS net_revenue,
       ROUND(100.0*SUM(TotalAmount)/(SELECT SUM(TotalAmount) FROM orders WHERE OrderStatus='Delivered'),1) AS share_pct
FROM orders WHERE OrderStatus='Delivered' GROUP BY City ORDER BY net_revenue DESC;

-- name: 4. Simple RFM base table (delivered orders)
SELECT CustomerID, CAST(julianday((SELECT MAX(OrderDate) FROM orders WHERE OrderStatus='Delivered')) - julianday(MAX(OrderDate)) AS INT) AS recency_days,
       COUNT(*) AS frequency, SUM(TotalAmount) AS monetary
FROM orders WHERE OrderStatus='Delivered' GROUP BY CustomerID ORDER BY monetary DESC LIMIT 10;

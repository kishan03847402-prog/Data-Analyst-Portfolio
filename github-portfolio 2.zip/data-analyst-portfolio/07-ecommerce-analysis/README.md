# E-Commerce Analysis: Revenue Leakage and RFM Customer Segmentation

How much revenue leaks through cancellations and returns, and which customers are worth protecting?

> **Dataset note:** this project uses a *demo / synthetic* dataset supplied for portfolio practice. All numbers below describe that file, not a real company or event. The code is schema-compatible: drop a real CSV with the same columns into `data/raw/` and re-run.

![dashboard](images/ecommerce_dashboard.png)

## Problem statement
An online store wants to understand revenue leakage and identify its most valuable and at-risk customers.

## Dataset
| | |
|---|---|
| File | `data/raw/07_Ecommerce_Demo.csv` |
| Size | 350 rows |
| Period | 2025-01-01 to 2025-06-29 |
| Columns | OrderID, OrderDate, CustomerID, Product, Category, Quantity, UnitPrice, PaymentMethod, OrderStatus, City, TotalAmount |

## Business questions
- How much of gross revenue is lost to cancellations and returns, and where?
- Which products, cities and payment methods drive net revenue?
- Which customer segments (RFM) drive revenue, and who is at risk?

## Approach
1. Net revenue = delivered orders only; separated gross, net, in-transit (shipped) and lost value.
2. Chi-square tests on loss rate by payment, city and product.
3. RFM scoring on delivered orders: recency quartiles, frequency (1 / 2 / 3+), monetary quartiles, mapped to six segments.

## Data quality audit
Every check is run by `analysis.py` and saved to `output/data_quality_audit.csv`.

| Check                                                                |   Rows affected |   % of rows | Action taken                                                                |
|:---------------------------------------------------------------------|----------------:|------------:|:----------------------------------------------------------------------------|
| Duplicate OrderID                                                    |               0 |           0 | none found                                                                  |
| Missing values (any column)                                          |               0 |           0 | none found                                                                  |
| TotalAmount != Quantity x UnitPrice                                  |               0 |           0 | none found                                                                  |
| Same product sold under >1 category                                  |             350 |         100 | kept; Category column unreliable, so category analysis uses Product instead |
| Same product with extreme price spread (min vs max unit price > 10x) |             350 |         100 | kept; revenue analysed, price-point conclusions avoided                     |

## Key findings
1. Gross order value 2,591,682; net delivered revenue 1,760,001. Cancelled and returned orders (18% of orders: 9.4% cancelled, 8.6% returned) removed 489,236, or 18.9% of gross value; another 342,445 is still in transit.
2. Loss rate differs by product: Book 30% and Headphones 26% vs Watch 4.5% (chi-square p = 0.037, the only statistically significant split; with 7 products, treat as a lead to verify).
3. By payment and city the gaps look large but are not significant: UPI 21% vs Net Banking 14% (p = 0.81); Patna 28% vs Kolkata 11% (p = 0.57, only 36 Patna orders).
4. Shoes gives the largest net-revenue share (18%), Delhi the top city (18%), Credit Card the top payment method (26%). Net revenue peaked in Apr-May (about 339K a month) and dipped 15% in June.
5. RFM on 150 customers with delivered orders: Loyal/High-value customers are 23% of customers but 39% of revenue; Champions 8% of customers and 15% of revenue. The top 20% of customers give 44% of revenue. 14 high-value customers are at risk (13% of revenue), and 28% of customers are lapsing.

## Recommendations
1. Run a win-back offer for the 14 at-risk high-value customers: they are 13% of revenue and haven't ordered for ~112 days on average.
2. Investigate Book and Headphones returns/cancellations (quality, description, delivery) before touching payment or city policy.
3. Build a simple loyalty path for Loyal and Champion customers (23% + 8% of customers, over half of revenue).

## Limitations
- 6 months and 350 orders; most customers have 1-3 orders, so RFM segments are small.
- Category column is inconsistent (same product in several categories), so product is used instead.
- Unit prices for the same product range 10x or more; price analysis is avoided.

## SQL
`sql/queries.sql` re-computes the key metrics in SQL (SQLite syntax, window functions). `analysis.py` executes them and writes the results to [`output/sql_results.md`](output/sql_results.md), so the SQL is tested, not just written.

## Tools
Python (pandas, scipy, matplotlib, seaborn), SQLite, Power BI ready CSVs

## How to run
```bash
pip install -r ../requirements.txt
python analysis.py
```
Creates `data/clean/`, `images/`, `output/` (summary CSVs for Power BI / Tableau, `findings.json`, `sql_results.md`).

## Project structure
```
data/raw/     input CSV(s), unchanged
data/clean/   validated data with derived columns
sql/          queries.sql
images/       dashboard PNG
output/       summary CSVs, data_quality_audit.csv, findings.json, sql_results.md
analysis.py   validation, analysis, charts, SQL run
```

"""Project 7 - E-commerce: revenue, cancellations/returns, payment & city mix, RFM customer segmentation.
Input: data/raw/07_Ecommerce_Demo.csv"""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from common import *
from scipy import stats

here = setup(__file__)
raw = pd.read_csv(here / "data/raw/07_Ecommerce_Demo.csv", parse_dates=["OrderDate"])
a = Audit(here, len(raw)); df = raw.copy()
a.check("Duplicate OrderID", df.OrderID.duplicated(), "none found")
a.check("Missing values (any column)", df.isna().any(axis=1), "none found")
a.check("TotalAmount != Quantity x UnitPrice", (df.TotalAmount - df.Quantity * df.UnitPrice).abs() > .01, "none found")
a.check("Same product sold under >1 category", (df.groupby("Product").Category.transform("nunique") > 1), "kept; Category column unreliable, so category analysis uses Product instead")
a.check("Same product with extreme price spread (min vs max unit price > 10x)", df.groupby("Product").UnitPrice.transform(lambda s: s.max() / s.min() > 10), "kept; revenue analysed, price-point conclusions avoided")
a.save()
df["Month"] = df.OrderDate.dt.to_period("M").dt.to_timestamp()
df["Delivered"] = df.OrderStatus == "Delivered"; df["Lost"] = df.OrderStatus.isin(["Cancelled", "Returned"])
df.to_csv(here / "data/clean/ecommerce_clean.csv", index=False)

n = len(df); gross = df.TotalAmount.sum(); net = df[df.Delivered].TotalAmount.sum(); shipped = df[df.OrderStatus == "Shipped"].TotalAmount.sum()
lost_val = df[df.Lost].TotalAmount.sum()
status = df.OrderStatus.value_counts()
def lossrate(by):
    t = df.groupby(by).agg(Orders=("OrderID", "count"), Lost=("Lost", "sum"), Cancelled=("OrderStatus", lambda s: (s == "Cancelled").sum()), Returned=("OrderStatus", lambda s: (s == "Returned").sum()), Gross=("TotalAmount", "sum"))
    t["Cancel+Return%"] = t.Lost / t.Orders * 100; return t.sort_values("Cancel+Return%", ascending=False)
pay, city, prod = lossrate("PaymentMethod"), lossrate("City"), lossrate("Product")
net_by = lambda by: df[df.Delivered].groupby(by).TotalAmount.sum().sort_values(ascending=False)
net_prod, net_city, net_pay = net_by("Product"), net_by("City"), net_by("PaymentMethod")
monthly = df.groupby("Month").agg(Orders=("OrderID", "count"), Gross=("TotalAmount", "sum")); monthly["Net(Delivered)"] = df[df.Delivered].groupby("Month").TotalAmount.sum()
monthly["MoM_Net%"] = monthly["Net(Delivered)"].pct_change() * 100
cod = df.PaymentMethod == "Cash on Delivery"
chi_p = stats.chi2_contingency(pd.crosstab(df.PaymentMethod, df.Lost))[1]
chi_c = stats.chi2_contingency(pd.crosstab(df.City, df.Lost))[1]
chi_pr = stats.chi2_contingency(pd.crosstab(df.Product, df.Lost))[1]

# ---- RFM on delivered orders
d = df[df.Delivered]; snap = d.OrderDate.max() + pd.Timedelta(days=1)
rfm = d.groupby("CustomerID").agg(Recency=("OrderDate", lambda s: (snap - s.max()).days), Frequency=("OrderID", "count"), Monetary=("TotalAmount", "sum"))
rfm["R"] = pd.qcut(rfm.Recency, 4, labels=[4, 3, 2, 1]).astype(int)
rfm["F"] = pd.cut(rfm.Frequency, [0, 1, 2, 100], labels=[1, 2, 3]).astype(int)   # 1 order / 2 orders / 3+ (ties make qcut unreliable)
rfm["M"] = pd.qcut(rfm.Monetary, 4, labels=[1, 2, 3, 4]).astype(int)
def seg(r):
    if r.R >= 3 and r.F >= 3 and r.M >= 3: return "Champions"
    if r.F >= 2 and r.M >= 3: return "Loyal / High value"
    if r.R >= 3 and r.F == 1: return "New customers"
    if r.R <= 2 and r.M >= 3: return "At risk (high value)"
    if r.R <= 2: return "Lapsing"
    return "Potential"
rfm["Segment"] = rfm.apply(seg, axis=1)
S = rfm.groupby("Segment").agg(Customers=("Monetary", "size"), Revenue=("Monetary", "sum"), AvgRecency=("Recency", "mean"), AvgOrders=("Frequency", "mean"))
S["Cust%"] = S.Customers / len(rfm) * 100; S["Rev%"] = S.Revenue / S.Revenue.sum() * 100; S = S.sort_values("Rev%", ascending=False)
rfm.to_csv(here / "output/rfm_customers.csv"); S.round(1).to_csv(here / "output/rfm_segments.csv")
for nme, t in [("payment", pay), ("city", city), ("product", prod), ("monthly", monthly)]: t.round(1).to_csv(here / f"output/{nme}_summary.csv")
top20 = int(np.ceil(len(rfm) * .2)); top20_share = rfm.Monetary.sort_values(ascending=False).head(top20).sum() / rfm.Monetary.sum() * 100
all_c = df.groupby("CustomerID").size()
F = dict(orders=n, period=f"{df.OrderDate.min().date()} to {df.OrderDate.max().date()}", customers=int(df.CustomerID.nunique()), gross=gross, net_delivered=net, shipped_value=shipped, lost_value=lost_val, lost_value_pct=lost_val / gross * 100,
         aov_delivered=d.TotalAmount.mean(), status_pct={k: round(v / n * 100, 1) for k, v in status.items()}, cancel_pct=status["Cancelled"] / n * 100, return_pct=status["Returned"] / n * 100, lost_pct=df.Lost.mean() * 100,
         pay_loss={k: round(v, 1) for k, v in pay["Cancel+Return%"].items()}, pay_worst=pay.index[0], pay_worst_v=pay["Cancel+Return%"].iloc[0], pay_best=pay.index[-1], pay_best_v=pay["Cancel+Return%"].iloc[-1], cod_loss=df[cod].Lost.mean() * 100, noncod_loss=df[~cod].Lost.mean() * 100,
         city_worst=city.index[0], city_worst_v=city["Cancel+Return%"].iloc[0], city_best=city.index[-1], city_best_v=city["Cancel+Return%"].iloc[-1], prod_worst=prod.index[0], prod_worst_v=prod["Cancel+Return%"].iloc[0],
         chi_pay_p=chi_p, chi_city_p=chi_c, chi_prod_p=chi_pr,
         top_product=net_prod.index[0], top_product_share=net_prod.iloc[0] / net * 100, top_city=net_city.index[0], top_city_share=net_city.iloc[0] / net * 100, top_pay=net_pay.index[0], top_pay_share=net_pay.iloc[0] / net * 100,
         best_month=monthly["Net(Delivered)"].idxmax().strftime("%b %Y"), best_month_v=monthly["Net(Delivered)"].max(), worst_month=monthly["Net(Delivered)"].idxmin().strftime("%b %Y"), worst_month_v=monthly["Net(Delivered)"].min(),
         rfm_customers=len(rfm), repeat_pct=(rfm.Frequency >= 2).mean() * 100, repeat_pct_all_orders=(all_c >= 2).mean() * 100, top20_cust_rev_share=top20_share,
         seg={k: dict(customers=int(r.Customers), cust_pct=round(r["Cust%"], 1), rev_pct=round(r["Rev%"], 1)) for k, r in S.iterrows()}, champions_cust_pct=S["Cust%"].get("Champions", 0), champions_rev_pct=S["Rev%"].get("Champions", 0))
save_findings(here, F)

fig = plt.figure(figsize=(16, 10.5)); gs = fig.add_gridspec(2, 3, top=0.88, hspace=0.42, wspace=0.3)
header(fig, "E-Commerce Analysis (Demo Dataset)", {"Orders": n, "Net revenue (delivered)": f"{net/1e6:.2f}M", "Cancel+Return": f"{df.Lost.mean()*100:.0f}% of orders", "Customers": F["customers"]})
ax = fig.add_subplot(gs[0, 0]); status.plot.bar(ax=ax, color=[GREEN, BLUE, RED, ORANGE], rot=0); ax.set_title("Order Status"); bar_labels(ax, "{:.0f}")
ax = fig.add_subplot(gs[0, 1:]); ax.plot(monthly.index.strftime("%b"), monthly.Gross / 1e3, marker="o", color=GREY, label="Gross (all orders)"); ax.plot(monthly.index.strftime("%b"), monthly["Net(Delivered)"] / 1e3, marker="o", color=BLUE, lw=2.5, label="Net (delivered only)")
ax.set_title("Monthly Revenue (thousands)"); ax.legend(frameon=False); ax.set_ylim(0)
ax = fig.add_subplot(gs[1, 0]); pay["Cancel+Return%"].sort_values().plot.barh(ax=ax, color=RED); ax.set_title("Cancel + Return % by Payment Method"); bar_labels(ax, "{:.0f}%"); ax.axvline(df.Lost.mean() * 100, color="#333", ls="--", lw=1)
ax = fig.add_subplot(gs[1, 1]); net_prod.sort_values().div(1e3).plot.barh(ax=ax, color=GREEN); ax.set_title("Net Revenue by Product (thousands)"); bar_labels(ax, "{:,.0f}")
ax = fig.add_subplot(gs[1, 2]); S["Rev%"].sort_values().plot.barh(ax=ax, color=PURPLE); ax.set_title("RFM Segments: % of Delivered Revenue"); bar_labels(ax, "{:.0f}%")
plt.savefig(here / "images/ecommerce_dashboard.png", dpi=150, bbox_inches="tight"); plt.close()
run_sql(here, {"orders": df.drop(columns=["Delivered", "Lost"]).assign(IsDelivered=df.Delivered.astype(int), IsLost=df.Lost.astype(int))})
print("\nFINDINGS"); [print(f"  {k}: {v}") for k, v in F.items()]; print(pay.round(1)); print(city.round(1)); print(prod.round(1)); print(S.round(1)); print(monthly.round(0))

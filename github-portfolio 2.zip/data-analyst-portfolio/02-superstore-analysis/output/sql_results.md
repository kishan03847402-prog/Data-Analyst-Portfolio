### 1. Margin by category

```sql
SELECT Category, ROUND(SUM(Sales),0) AS sales, ROUND(SUM(Profit),0) AS profit, ROUND(100.0*SUM(Profit)/SUM(Sales),1) AS margin_pct
FROM orders GROUP BY Category ORDER BY margin_pct DESC;
```

| Category        |   sales |   profit |   margin_pct |
|:----------------|--------:|---------:|-------------:|
| Office Supplies |   80654 |    11860 |         14.7 |
| Technology      |   83542 |    11191 |         13.4 |
| Furniture       |   90056 |    11731 |         13   |

### 2. Sub-categories ranked by loss rate

```sql
SELECT Category, SubCategory, COUNT(*) AS orders, SUM(CASE WHEN Profit < 0 THEN 1 ELSE 0 END) AS loss_orders,
       ROUND(100.0*SUM(CASE WHEN Profit < 0 THEN 1 ELSE 0 END)/COUNT(*),1) AS loss_rate_pct,
       ROUND(100.0*SUM(Profit)/SUM(Sales),1) AS margin_pct
FROM orders GROUP BY Category, SubCategory ORDER BY loss_rate_pct DESC;
```

| Category        | SubCategory   |   orders |   loss_orders |   loss_rate_pct |   margin_pct |
|:----------------|:--------------|---------:|--------------:|----------------:|-------------:|
| Furniture       | Bookcase      |       35 |             9 |            25.7 |         10.9 |
| Office Supplies | Binder        |       31 |             7 |            22.6 |         13.6 |
| Office Supplies | Paper         |       45 |             9 |            20   |         13   |
| Furniture       | Chair         |       36 |             6 |            16.7 |         13.7 |
| Technology      | Laptop        |       39 |             6 |            15.4 |         13.7 |
| Furniture       | Desk          |       55 |             8 |            14.5 |         14.2 |
| Technology      | Printer       |       44 |             6 |            13.6 |         13.6 |
| Technology      | Phone         |       30 |             4 |            13.3 |         12.7 |
| Office Supplies | Pen           |       35 |             1 |             2.9 |         17.7 |

### 3. Discount impact

```sql
SELECT ROUND(Discount*100) || '%' AS discount, COUNT(*) AS orders, ROUND(100.0*SUM(Profit)/SUM(Sales),1) AS margin_pct,
       ROUND(100.0*SUM(CASE WHEN Profit < 0 THEN 1 ELSE 0 END)/COUNT(*),1) AS loss_rate_pct
FROM orders GROUP BY Discount ORDER BY Discount;
```

| discount   |   orders |   margin_pct |   loss_rate_pct |
|:-----------|---------:|-------------:|----------------:|
| 0.0%       |       84 |         13.1 |            20.2 |
| 10.0%      |       68 |         14.5 |            16.2 |
| 15.0%      |       63 |         13.7 |            15.9 |
| 20.0%      |       67 |         13   |            11.9 |
| 5.0%       |       68 |         14.2 |            14.7 |

### 4. Top 10 customers and their share of sales

```sql
WITH c AS (SELECT CustomerID, SUM(Sales) AS sales, SUM(Profit) AS profit FROM orders GROUP BY CustomerID)
SELECT CustomerID, ROUND(sales,0) AS sales, ROUND(profit,0) AS profit,
       ROUND(100.0*sales/(SELECT SUM(Sales) FROM orders),1) AS share_pct
FROM c ORDER BY sales DESC LIMIT 10;
```

| CustomerID   |   sales |   profit |   share_pct |
|:-------------|--------:|---------:|------------:|
| C115         |    9844 |     1182 |         3.9 |
| C122         |    7670 |      504 |         3   |
| C169         |    6557 |     1494 |         2.6 |
| C114         |    6508 |      623 |         2.6 |
| C135         |    6343 |      965 |         2.5 |
| C139         |    5773 |      957 |         2.3 |
| C149         |    5706 |      353 |         2.2 |
| C110         |    5342 |      696 |         2.1 |
| C128         |    5214 |      418 |         2.1 |
| C174         |    5172 |     1108 |         2   |

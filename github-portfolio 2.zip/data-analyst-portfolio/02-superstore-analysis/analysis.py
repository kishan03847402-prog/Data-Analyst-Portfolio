"""Project 2 - Superstore: profitability, discount impact, customers.
Input: data/raw/02_Superstore_Demo.csv"""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from common import *
from scipy import stats

here = setup(__file__)
raw = pd.read_csv(here / "data/raw/02_Superstore_Demo.csv", parse_dates=["OrderDate"])
a = Audit(here, len(raw)); df = raw.copy()
a.check("Duplicate OrderID", df.OrderID.duplicated(), "none found")
a.check("Missing values (any column)", df.isna().any(axis=1), "none found")
a.check("Discount outside 0-1", ~df.Discount.between(0, 1), "none found")
a.check("Sales <= 0 or Quantity <= 0", (df.Sales <= 0) | (df.Quantity <= 0), "none found")
a.check("Loss-making orders (Profit < 0)", df.Profit < 0, "kept - they are the subject of the analysis")
a.save()

df["Margin%"] = df.Profit / df.Sales * 100
df["Month"] = df.OrderDate.dt.to_period("M").dt.to_timestamp()
df["DiscountBand"] = pd.cut(df.Discount, [-.01, 0, .05, .10, .15, .20], labels=["0%", "5%", "10%", "15%", "20%"])
df["Loss"] = df.Profit < 0
df.to_csv(here / "data/clean/superstore_clean.csv", index=False)

sales, prof = df.Sales.sum(), df.Profit.sum()
def agg(by):
    t = df.groupby(by, observed=True).agg(Sales=("Sales", "sum"), Profit=("Profit", "sum"), Orders=("OrderID", "count"), LossOrders=("Loss", "sum"), AvgDiscount=("Discount", "mean"))
    t["Margin%"] = t.Profit / t.Sales * 100; t["LossRate%"] = t.LossOrders / t.Orders * 100
    return t
cat, sub, reg, disc = agg("Category"), agg(["Category", "SubCategory"]).sort_values("Margin%"), agg("Region"), agg("DiscountBand")
month = agg("Month")
cust = df.groupby("CustomerID").agg(Sales=("Sales", "sum"), Profit=("Profit", "sum"), Orders=("OrderID", "count")).sort_values("Sales", ascending=False)
top10_share = cust.Sales.head(10).sum() / sales * 100
for n, t in [("category", cat), ("subcategory", sub), ("region", reg), ("discount_band", disc), ("monthly", month), ("customers", cust)]: t.round(2).to_csv(here / f"output/{n}_summary.csv")

rho, p_rho = stats.spearmanr(df.Discount, df["Margin%"])
hi = df[df.Discount >= .15]["Margin%"]; lo = df[df.Discount <= .05]["Margin%"]
u, p_u = stats.mannwhitneyu(hi, lo)
# loss orders: where do they come from?
loss_sub = sub.sort_values("LossRate%", ascending=False)
F = dict(rows=len(df), period=f"{df.OrderDate.min().date()} to {df.OrderDate.max().date()}", sales=sales, profit=prof, margin_pct=prof / sales * 100,
         customers=df.CustomerID.nunique(), loss_orders=int(df.Loss.sum()), loss_rate=df.Loss.mean() * 100, loss_total=df[df.Loss].Profit.sum(),
         loss_amount_pct_of_profit=abs(df[df.Loss].Profit.sum()) / prof * 100,
         best_cat=cat["Margin%"].idxmax(), best_cat_m=cat["Margin%"].max(), worst_cat=cat["Margin%"].idxmin(), worst_cat_m=cat["Margin%"].min(),
         best_sub=sub["Margin%"].idxmax(), best_sub_m=sub["Margin%"].max(), worst_sub=sub["Margin%"].idxmin(), worst_sub_m=sub["Margin%"].min(),
         highest_loss_rate_sub=loss_sub.index[0], highest_loss_rate_v=loss_sub["LossRate%"].iloc[0],
         top_region_sales=reg.Sales.idxmax(), top_region_share=reg.Sales.max() / sales * 100, best_region_margin=reg["Margin%"].idxmax(), best_region_margin_v=reg["Margin%"].max(),
         worst_region_margin=reg["Margin%"].idxmin(), worst_region_margin_v=reg["Margin%"].min(),
         margin_by_discount={str(k): round(v, 2) for k, v in disc["Margin%"].items()}, lossrate_by_discount={str(k): round(v, 1) for k, v in disc["LossRate%"].items()},
         spearman_rho=rho, spearman_p=p_rho, mw_p=p_u, margin_hi_disc_median=hi.median(), margin_lo_disc_median=lo.median(),
         top10_customer_share=top10_share, share_sales_discounted=(df.Discount > 0).mean() * 100, sales_at_15plus=df[df.Discount >= .15].Sales.sum() / sales * 100)
save_findings(here, F)

fig = plt.figure(figsize=(16, 10.5)); gs = fig.add_gridspec(2, 3, top=0.88, hspace=0.4, wspace=0.3)
header(fig, "Superstore Profitability (Demo Dataset)", {"Sales": f"{sales/1e3:,.0f}K", "Profit": f"{prof/1e3:,.1f}K", "Margin": f"{prof/sales*100:.1f}%", "Loss orders": f"{df.Loss.mean()*100:.0f}%"})
ax = fig.add_subplot(gs[0, 0]); cat["Margin%"].plot.bar(ax=ax, color=[BLUE, GREEN, ORANGE], rot=0); ax.set_title("Profit Margin % by Category"); bar_labels(ax, "{:.1f}")
ax = fig.add_subplot(gs[0, 1:]); s = sub["Margin%"].reset_index(); s["lab"] = s.SubCategory
ax.barh(s.lab, s["Margin%"], color=[RED if v < sub["Margin%"].median() else GREEN for v in s["Margin%"]]); ax.set_title("Profit Margin % by Sub-Category (red = below median)")
for i, v in enumerate(s["Margin%"]): ax.text(v + .1, i, f"{v:.1f}", va="center", fontsize=9)
ax = fig.add_subplot(gs[1, 0]); disc["Margin%"].plot.bar(ax=ax, color=PURPLE, rot=0); ax.set_title("Margin % by Discount Level"); bar_labels(ax, "{:.1f}"); ax.set_xlabel("")
ax = fig.add_subplot(gs[1, 1]); disc["LossRate%"].plot.bar(ax=ax, color=RED, rot=0); ax.set_title("% of Orders Losing Money by Discount"); bar_labels(ax, "{:.0f}%"); ax.set_xlabel("")
ax = fig.add_subplot(gs[1, 2]); reg["Margin%"].sort_values().plot.barh(ax=ax, color=BLUE); ax.set_title("Margin % by Region"); bar_labels(ax, "{:.1f}")
plt.savefig(here / "images/superstore_dashboard.png", dpi=150, bbox_inches="tight"); plt.close()
run_sql(here, {"orders": df})
print("\nFINDINGS"); [print(f"  {k}: {v}") for k, v in F.items()]; print(cat.round(1)); print(sub.round(1)); print(disc.round(1)); print(reg.round(1))

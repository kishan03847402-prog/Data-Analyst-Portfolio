# Superstore Profitability and Discount Analysis

Which products quietly lose money, and do discounts really hurt profit?

> **Dataset note:** this project uses a *demo / synthetic* dataset supplied for portfolio practice. All numbers below describe that file, not a real company or event. The code is schema-compatible: drop a real CSV with the same columns into `data/raw/` and re-run.

![dashboard](images/superstore_dashboard.png)

## Problem statement
A retailer wants to know which categories, sub-categories and regions are profitable, and whether discounting erodes margin.

## Dataset
| | |
|---|---|
| File | `data/raw/02_Superstore_Demo.csv` |
| Size | 350 rows |
| Period | 2025-01-01 to 2025-06-29 |
| Columns | OrderID, OrderDate, CustomerID, Region, Category, SubCategory, Sales, Quantity, Discount, Profit |

## Business questions
- Which category, sub-category and region have the best and worst margin?
- What share of orders lose money, and where do they come from?
- Is there a statistical link between discount level and profit margin?

## Approach
1. Computed margin = profit / sales at order, sub-category, region and discount-band level.
2. Tested discount vs order margin with Spearman correlation and a Mann-Whitney test (high vs low discount).
3. Sized customer concentration (top 10 customers).

## Data quality audit
Every check is run by `analysis.py` and saved to `output/data_quality_audit.csv`.

| Check                           |   Rows affected |   % of rows | Action taken                                |
|:--------------------------------|----------------:|------------:|:--------------------------------------------|
| Duplicate OrderID               |               0 |           0 | none found                                  |
| Missing values (any column)     |               0 |           0 | none found                                  |
| Discount outside 0-1            |               0 |           0 | none found                                  |
| Sales <= 0 or Quantity <= 0     |               0 |           0 | none found                                  |
| Loss-making orders (Profit < 0) |              56 |          16 | kept - they are the subject of the analysis |

## Key findings
1. Sales 254,252, profit 34,782, margin 13.7%. 56 of 350 orders (16%) lost money, but those losses total only 1,633 (4.7% of profit).
2. Furniture has the lowest category margin (13.0%) vs Office Supplies (14.7%). Bookcase is the weakest sub-category: 10.9% margin and 26% of its orders lose money. Pen is the strongest (17.7% margin, 2.9% loss rate).
3. Discounts show no measurable damage in this data: margin is 13.1% at 0% discount and 13.0% at 20%. Spearman rho = -0.02 (p = 0.66), so the relationship is statistically indistinguishable from zero.
4. 76% of orders carry a discount, and 36% of sales come at 15%+ discounts.
5. East is the healthiest region (15.0% margin, only 8% loss-making orders); North has the lowest margin (12.6%). The top 10 customers give 25% of sales.

## Recommendations
1. Run a cost and pricing review on Bookcase, and on Binder (22.6% loss rate) and Paper (20.0%).
2. Do not cut discounts blindly: this data shows no discount-margin link. Test it with a controlled pricing experiment first.
3. Study what East does differently: its loss-order rate (8%) is half of the other regions (16-19%).

## Limitations
- Margin differences between categories are small (13-15%) on 350 orders over 6 months.
- Discount has only 5 levels (0-20%), so very deep discounts are not covered.
- No cost, shipping or return fields, so margin is as given in the Profit column.

## SQL
`sql/queries.sql` re-computes the key metrics in SQL (SQLite syntax, window functions). `analysis.py` executes them and writes the results to [`output/sql_results.md`](output/sql_results.md), so the SQL is tested, not just written.

## Tools
Python (pandas, scipy, matplotlib, seaborn), SQLite, Tableau / Power BI ready CSVs

## How to run
```bash
pip install -r ../requirements.txt
python analysis.py
```
Creates `data/clean/`, `images/`, `output/` (summary CSVs for Power BI / Tableau, `findings.json`, `sql_results.md`).

## Project structure
```
data/raw/     input CSV(s), unchanged
data/clean/   validated data with derived columns
sql/          queries.sql
images/       dashboard PNG
output/       summary CSVs, data_quality_audit.csv, findings.json, sql_results.md
analysis.py   validation, analysis, charts, SQL run
```

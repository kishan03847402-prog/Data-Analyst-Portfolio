-- name: 1. Margin by category
SELECT Category, ROUND(SUM(Sales),0) AS sales, ROUND(SUM(Profit),0) AS profit, ROUND(100.0*SUM(Profit)/SUM(Sales),1) AS margin_pct
FROM orders GROUP BY Category ORDER BY margin_pct DESC;

-- name: 2. Sub-categories ranked by loss rate
SELECT Category, SubCategory, COUNT(*) AS orders, SUM(CASE WHEN Profit < 0 THEN 1 ELSE 0 END) AS loss_orders,
       ROUND(100.0*SUM(CASE WHEN Profit < 0 THEN 1 ELSE 0 END)/COUNT(*),1) AS loss_rate_pct,
       ROUND(100.0*SUM(Profit)/SUM(Sales),1) AS margin_pct
FROM orders GROUP BY Category, SubCategory ORDER BY loss_rate_pct DESC;

-- name: 3. Discount impact
SELECT ROUND(Discount*100) || '%' AS discount, COUNT(*) AS orders, ROUND(100.0*SUM(Profit)/SUM(Sales),1) AS margin_pct,
       ROUND(100.0*SUM(CASE WHEN Profit < 0 THEN 1 ELSE 0 END)/COUNT(*),1) AS loss_rate_pct
FROM orders GROUP BY Discount ORDER BY Discount;

-- name: 4. Top 10 customers and their share of sales
WITH c AS (SELECT CustomerID, SUM(Sales) AS sales, SUM(Profit) AS profit FROM orders GROUP BY CustomerID)
SELECT CustomerID, ROUND(sales,0) AS sales, ROUND(profit,0) AS profit,
       ROUND(100.0*sales/(SELECT SUM(Sales) FROM orders),1) AS share_pct
FROM c ORDER BY sales DESC LIMIT 10;

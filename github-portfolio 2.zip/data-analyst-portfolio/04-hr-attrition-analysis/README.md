# HR Attrition Analysis

Who leaves, and which factors show a link that is statistically real rather than noise?

> **Dataset note:** this project uses a *demo / synthetic* dataset supplied for portfolio practice. All numbers below describe that file, not a real company or event. The code is schema-compatible: drop a real CSV with the same columns into `data/raw/` and re-run.

![dashboard](images/hr_attrition_dashboard.png)

## Problem statement
HR wants to understand attrition drivers to target retention effort.

## Dataset
| | |
|---|---|
| File | `data/raw/04_HR_Analytics_Demo.csv` |
| Size | 220 rows |
| Period | snapshot (no dates) |
| Columns | EmployeeID, Age, Department, JobRole, Gender, Education, MonthlySalary, YearsAtCompany, JobSatisfaction, Attrition |

## Business questions
- What is the overall attrition rate and where is it highest?
- Do satisfaction, salary, age, tenure, department or role relate to leaving?
- Which differences are statistically meaningful given the sample size?

## Approach
1. Computed attrition rate for every segment with 95% Wilson confidence intervals.
2. Chi-square tests per factor; Mann-Whitney tests for salary and age.
3. Flagged impossible tenure values and excluded them only from the tenure analysis.

## Data quality audit
Every check is run by `analysis.py` and saved to `output/data_quality_audit.csv`.

| Check                                                      |   Rows affected |   % of rows | Action taken                                |
|:-----------------------------------------------------------|----------------:|------------:|:--------------------------------------------|
| Duplicate EmployeeID                                       |               0 |         0   | none found                                  |
| Missing values (any column)                                |               0 |         0   | none found                                  |
| Age outside 18-65                                          |               0 |         0   | none found                                  |
| JobSatisfaction outside 1-5                                |               0 |         0   | none found                                  |
| YearsAtCompany > Age-18 (joined before age 18: impossible) |              54 |        24.5 | flagged; excluded ONLY from tenure analysis |

## Key findings
1. 38 of 220 employees left: attrition is 17.3%.
2. Marketing has the highest departmental attrition (23.7%, 38 employees) and Finance the lowest (11.4%), but the gap is not statistically significant (chi-square p = 0.73).
3. Age is the only factor with a statistical signal: leavers have a median age of 36.5 vs 41 for stayers (Mann-Whitney p = 0.037). Attrition falls from 25% for ages 21-29 to 10% for 50-60.
4. Pay does not separate leavers from stayers: median salary 80,790 (left) vs 82,712 (stayed), p = 0.90.
5. Job satisfaction of 5 stands out at 7% attrition (3 of 43) vs 18-21% for scores 1-4, yet the overall test is not significant (p = 0.38). No other factor passed the 5% threshold.

## Recommendations
1. Treat early-career employees (under 30) as the priority retention hypothesis: highest rate (25%) and the only significant signal.
2. Do not launch department- or pay-specific programmes on this evidence: differences there are within sampling noise.
3. Collect more data (overtime, manager, exit reasons, promotion history) and 3+ years of snapshots, then re-test.

## Limitations
- Only 38 leavers: confidence intervals are wide (see the whiskers in the chart).
- 54 rows (25%) have tenure longer than possible given age, so tenure results use 166 rows.
- Correlation only: no causal claims.

## SQL
`sql/queries.sql` re-computes the key metrics in SQL (SQLite syntax, window functions). `analysis.py` executes them and writes the results to [`output/sql_results.md`](output/sql_results.md), so the SQL is tested, not just written.

## Tools
Python (pandas, scipy, matplotlib, seaborn), SQLite, Power BI ready CSVs

## How to run
```bash
pip install -r ../requirements.txt
python analysis.py
```
Creates `data/clean/`, `images/`, `output/` (summary CSVs for Power BI / Tableau, `findings.json`, `sql_results.md`).

## Project structure
```
data/raw/     input CSV(s), unchanged
data/clean/   validated data with derived columns
sql/          queries.sql
images/       dashboard PNG
output/       summary CSVs, data_quality_audit.csv, findings.json, sql_results.md
analysis.py   validation, analysis, charts, SQL run
```

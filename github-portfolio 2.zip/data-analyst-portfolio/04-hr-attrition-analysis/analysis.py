"""Project 4 - HR attrition: who leaves, and which factors show a (statistically testable) link?
Input: data/raw/04_HR_Analytics_Demo.csv"""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from common import *
from scipy import stats

here = setup(__file__)
raw = pd.read_csv(here / "data/raw/04_HR_Analytics_Demo.csv")
a = Audit(here, len(raw)); df = raw.copy()
a.check("Duplicate EmployeeID", df.EmployeeID.duplicated(), "none found")
a.check("Missing values (any column)", df.isna().any(axis=1), "none found")
a.check("Age outside 18-65", ~df.Age.between(18, 65), "none found")
a.check("JobSatisfaction outside 1-5", ~df.JobSatisfaction.between(1, 5), "none found")
bad_tenure = df.YearsAtCompany > (df.Age - 18)
a.check("YearsAtCompany > Age-18 (joined before age 18: impossible)", bad_tenure, "flagged; excluded ONLY from tenure analysis")
df["TenureValid"] = ~bad_tenure
a.save()

df["Left"] = (df.Attrition == "Yes").astype(int)
df["AgeBand"] = pd.cut(df.Age, [20, 29, 39, 49, 60], labels=["21-29", "30-39", "40-49", "50-60"])
df["SalaryBand"] = pd.qcut(df.MonthlySalary, 4, labels=["Q1 (lowest)", "Q2", "Q3", "Q4 (highest)"])
df["TenureBand"] = pd.cut(df.YearsAtCompany.where(df.TenureValid), [-1, 2, 5, 10, 25], labels=["0-2 yrs", "3-5 yrs", "6-10 yrs", "11+ yrs"])
df.to_csv(here / "data/clean/hr_clean.csv", index=False)

def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k / n; d = 1 + z * z / n; c = p + z * z / (2 * n); w = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return ((c - w) / d * 100, (c + w) / d * 100)
def rate(by, data=df):
    t = data.groupby(by, observed=True).agg(Employees=("Left", "size"), Left=("Left", "sum")); t["Attrition%"] = t.Left / t.Employees * 100
    ci = [wilson(k, n) for k, n in zip(t.Left, t.Employees)]; t["CI_low"], t["CI_high"] = [c[0] for c in ci], [c[1] for c in ci]
    return t
overall = df.Left.mean() * 100
tabs = {k: rate(k) for k in ["Department", "JobRole", "Education", "Gender", "JobSatisfaction", "AgeBand", "SalaryBand"]}
tabs["TenureBand"] = rate("TenureBand", df[df.TenureValid])
for k, t in tabs.items(): t.round(2).to_csv(here / f"output/attrition_by_{k.lower()}.csv")

# hypothesis tests (alpha=0.05); small sample -> report p-values honestly
def chi(col, data=df):
    ct = pd.crosstab(data[col], data.Left); c, p, _, _ = stats.chi2_contingency(ct); return float(p)
tests = {c: chi(c) for c in ["Department", "JobRole", "Education", "Gender", "JobSatisfaction", "AgeBand", "SalaryBand"]}
tests["TenureBand"] = chi("TenureBand", df[df.TenureValid])
sal_u, sal_p = stats.mannwhitneyu(df[df.Left == 1].MonthlySalary, df[df.Left == 0].MonthlySalary)
age_u, age_p = stats.mannwhitneyu(df[df.Left == 1].Age, df[df.Left == 0].Age)
low_sat = df[df.JobSatisfaction <= 2].Left.mean() * 100; hi_sat = df[df.JobSatisfaction >= 3].Left.mean() * 100
d, jr = tabs["Department"], tabs["JobRole"]
F = dict(rows=len(df), employees_left=int(df.Left.sum()), attrition_pct=overall,
         highest_dept=d["Attrition%"].idxmax(), highest_dept_v=d["Attrition%"].max(), highest_dept_n=int(d.Employees[d["Attrition%"].idxmax()]),
         lowest_dept=d["Attrition%"].idxmin(), lowest_dept_v=d["Attrition%"].min(),
         highest_role=jr["Attrition%"].idxmax(), highest_role_v=jr["Attrition%"].max(), lowest_role=jr["Attrition%"].idxmin(), lowest_role_v=jr["Attrition%"].min(),
         sat_rates={int(k): round(v, 1) for k, v in tabs["JobSatisfaction"]["Attrition%"].items()}, low_sat_rate=low_sat, high_sat_rate=hi_sat,
         age_rates={str(k): round(v, 1) for k, v in tabs["AgeBand"]["Attrition%"].items()},
         salary_rates={str(k): round(v, 1) for k, v in tabs["SalaryBand"]["Attrition%"].items()},
         tenure_rates={str(k): round(v, 1) for k, v in tabs["TenureBand"]["Attrition%"].items()},
         median_salary_left=df[df.Left == 1].MonthlySalary.median(), median_salary_stayed=df[df.Left == 0].MonthlySalary.median(), salary_mw_p=sal_p,
         median_age_left=df[df.Left == 1].Age.median(), median_age_stayed=df[df.Left == 0].Age.median(), age_mw_p=age_p,
         chi2_p={k: round(v, 3) for k, v in tests.items()}, significant=[k for k, v in tests.items() if v < .05],
         tenure_valid_rows=int(df.TenureValid.sum()))
save_findings(here, F)

fig = plt.figure(figsize=(16, 10.5)); gs = fig.add_gridspec(2, 3, top=0.88, hspace=0.42, wspace=0.3)
header(fig, "HR Attrition Analysis (Demo Dataset)", {"Employees": len(df), "Left": int(df.Left.sum()), "Attrition": f"{overall:.1f}%"})
def rbar(ax, t, title, color=BLUE, rot=0, horizontal=False):
    s = t["Attrition%"]; err = [s - t.CI_low, t.CI_high - s]
    if horizontal:
        s = s.sort_values(); err = [s - t.CI_low[s.index], t.CI_high[s.index] - s]
        ax.barh(s.index.astype(str), s, xerr=err, color=color, error_kw=dict(ecolor="#555", lw=1)); [ax.text(v + 1, i, f"{v:.0f}%", va="center", fontsize=9) for i, v in enumerate(s)]
    else:
        ax.bar(s.index.astype(str), s, yerr=err, color=color, error_kw=dict(ecolor="#555", lw=1)); [ax.text(i, v + 2, f"{v:.0f}%", ha="center", fontsize=9) for i, v in enumerate(s)]
        ax.tick_params(axis="x", rotation=rot)
    ax.axvline(overall, color=RED, ls="--", lw=1) if horizontal else ax.axhline(overall, color=RED, ls="--", lw=1)
    ax.set_title(title); ax.set_xlabel(""); ax.set_ylabel("")
rbar(fig.add_subplot(gs[0, 0]), tabs["Department"], "Attrition % by Department", BLUE, 30)
rbar(fig.add_subplot(gs[0, 1]), tabs["JobRole"], "Attrition % by Job Role", GREEN, 0, True)
rbar(fig.add_subplot(gs[0, 2]), tabs["JobSatisfaction"], "Attrition % by Job Satisfaction (1-5)", ORANGE)
rbar(fig.add_subplot(gs[1, 0]), tabs["AgeBand"], "Attrition % by Age Band", PURPLE)
rbar(fig.add_subplot(gs[1, 1]), tabs["SalaryBand"], "Attrition % by Salary Quartile", BLUE, 15)
rbar(fig.add_subplot(gs[1, 2]), tabs["TenureBand"], "Attrition % by Tenure (valid rows only)", GREEN)
fig.text(0.01, 0.005, "Bars = attrition rate, whiskers = 95% confidence interval, red dashed line = overall rate. Wide whiskers mean small groups: read differences with care.", fontsize=9.5, color="#555")
plt.savefig(here / "images/hr_attrition_dashboard.png", dpi=150, bbox_inches="tight"); plt.close()
run_sql(here, {"employees": df.drop(columns=["AgeBand", "SalaryBand", "TenureBand"])})
print("\nFINDINGS"); [print(f"  {k}: {v}") for k, v in F.items()]
for k, t in tabs.items(): print(t.round(1))

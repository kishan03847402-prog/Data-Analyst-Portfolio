-- name: 1. Overall attrition
SELECT COUNT(*) AS employees, SUM(Left) AS left_company, ROUND(100.0*AVG(Left),1) AS attrition_pct FROM employees;

-- name: 2. Attrition by department
SELECT Department, COUNT(*) AS employees, SUM(Left) AS left_company, ROUND(100.0*AVG(Left),1) AS attrition_pct
FROM employees GROUP BY Department ORDER BY attrition_pct DESC;

-- name: 3. Attrition by job satisfaction score
SELECT JobSatisfaction, COUNT(*) AS employees, ROUND(100.0*AVG(Left),1) AS attrition_pct
FROM employees GROUP BY JobSatisfaction ORDER BY JobSatisfaction;

-- name: 4. Department + role combinations above the company average (min 8 employees)
SELECT Department, JobRole, COUNT(*) AS employees, ROUND(100.0*AVG(Left),1) AS attrition_pct
FROM employees GROUP BY Department, JobRole
HAVING COUNT(*) >= 8 AND AVG(Left) > (SELECT AVG(Left) FROM employees)
ORDER BY attrition_pct DESC LIMIT 10;

### 1. Overall attrition

```sql
SELECT COUNT(*) AS employees, SUM(Left) AS left_company, ROUND(100.0*AVG(Left),1) AS attrition_pct FROM employees;
```

|   employees |   left_company |   attrition_pct |
|------------:|---------------:|----------------:|
|         220 |             38 |            17.3 |

### 2. Attrition by department

```sql
SELECT Department, COUNT(*) AS employees, SUM(Left) AS left_company, ROUND(100.0*AVG(Left),1) AS attrition_pct
FROM employees GROUP BY Department ORDER BY attrition_pct DESC;
```

| Department   |   employees |   left_company |   attrition_pct |
|:-------------|------------:|---------------:|----------------:|
| Marketing    |          38 |              9 |            23.7 |
| Sales        |          29 |              6 |            20.7 |
| Operations   |          44 |              8 |            18.2 |
| IT           |          34 |              6 |            17.6 |
| HR           |          40 |              5 |            12.5 |
| Finance      |          35 |              4 |            11.4 |

### 3. Attrition by job satisfaction score

```sql
SELECT JobSatisfaction, COUNT(*) AS employees, ROUND(100.0*AVG(Left),1) AS attrition_pct
FROM employees GROUP BY JobSatisfaction ORDER BY JobSatisfaction;
```

|   JobSatisfaction |   employees |   attrition_pct |
|------------------:|------------:|----------------:|
|                 1 |          47 |            21.3 |
|                 2 |          38 |            21.1 |
|                 3 |          49 |            18.4 |
|                 4 |          43 |            18.6 |
|                 5 |          43 |             7   |

### 4. Department + role combinations above the company average (min 8 employees)

```sql
SELECT Department, JobRole, COUNT(*) AS employees, ROUND(100.0*AVG(Left),1) AS attrition_pct
FROM employees GROUP BY Department, JobRole
HAVING COUNT(*) >= 8 AND AVG(Left) > (SELECT AVG(Left) FROM employees)
ORDER BY attrition_pct DESC LIMIT 10;
```

| Department   | JobRole    |   employees |   attrition_pct |
|:-------------|:-----------|------------:|----------------:|
| HR           | Specialist |           9 |            33.3 |
| Operations   | Analyst    |           9 |            33.3 |
| Marketing    | Executive  |          11 |            27.3 |
| IT           | Executive  |           8 |            25   |
| IT           | Manager    |           8 |            25   |
| IT           | Specialist |           9 |            22.2 |
| Sales        | Specialist |           9 |            22.2 |
| Operations   | Manager    |          14 |            21.4 |

# Netflix Catalogue: Exploratory Data Analysis

What does the catalogue look like by type, genre, country and age, and how fast does it grow?

> **Dataset note:** this project uses a *demo / synthetic* dataset supplied for portfolio practice. All numbers below describe that file, not a real company or event. The code is schema-compatible: drop a real CSV with the same columns into `data/raw/` and re-run.

![dashboard](images/netflix_dashboard.png)

## Problem statement
A content team wants a fact base on catalogue composition and recent additions to guide licensing and production.

## Dataset
| | |
|---|---|
| File | `data/raw/03_Netflix_Demo.csv` |
| Size | 180 rows |
| Period | 2024-01-01 to 2025-12-26 (date added) |
| Columns | ShowID, Title, Type, ReleaseYear, AgeRating, Genre, Country, Duration, DateAdded |

## Business questions
- What is the split between movies and TV shows, and between genres?
- Which countries and age ratings dominate?
- How many titles were added per quarter, and how old is the content when added?

## Approach
1. Parsed Duration into value + unit, derived year/quarter added and content age.
2. Audited logical consistency (type vs duration, added vs release year) and excluded only the affected rows from the affected metric.
3. Cross-tabulated genre x type and country x genre.

## Data quality audit
Every check is run by `analysis.py` and saved to `output/data_quality_audit.csv`.

| Check                                                           |   Rows affected |   % of rows | Action taken                                                                                  |
|:----------------------------------------------------------------|----------------:|------------:|:----------------------------------------------------------------------------------------------|
| Duplicate ShowID                                                |               0 |         0   | none found                                                                                    |
| Missing values (any column)                                     |               0 |         0   | none found                                                                                    |
| Repeated Title (same title, different ShowID/attributes)        |             172 |        95.6 | kept - ShowID is the key; titles reused in this demo data, so title-level counts are NOT used |
| Type/Duration conflict (Movie in 'Seasons' or TV Show in 'min') |              98 |        54.4 | flagged; excluded ONLY from duration analysis                                                 |
| Added to Netflix before its release year                        |               1 |         0.6 | kept; excluded from 'content age' calc                                                        |

## Key findings
1. The 180 rows split 46% movies / 54% TV shows. Drama is the biggest genre (18%), Action the smallest (12%).
2. Genres differ by format: Thriller is movie-heavy (17 movies vs 9 TV shows) while Drama is TV-heavy (21 TV shows vs 12 movies).
3. India leads with 24% of titles; India, United Kingdom and United States together hold 58%.
4. Additions grew from 84 titles in 2024 to 96 in 2025 (+14%), peaking in 2025 Q1 with 26.
5. The catalogue skews old: median content age at addition is 16 years and only 32% of titles were released in 2015 or later. U is the most common rating (31%); 22% are adult (A).

## Recommendations
1. If freshness matters, rebalance licensing toward post-2015 releases: they are under a third of the catalogue.
2. Genre by format is uneven (Thriller films, Drama series), which gives a simple rule for where to add TV vs movies.
3. Fix source data first: titles and duration fields need validation at ingestion (see audit).

## Limitations
- 98 of 180 rows (54%) have a type/duration conflict (movie with 'Seasons', TV show with 'min'), so duration analysis is deliberately not reported.
- Only 8 distinct titles appear across 180 rows, so analysis is by ShowID, not by title.
- Two years of additions only: growth rate is indicative.

## SQL
`sql/queries.sql` re-computes the key metrics in SQL (SQLite syntax, window functions). `analysis.py` executes them and writes the results to [`output/sql_results.md`](output/sql_results.md), so the SQL is tested, not just written.

## Tools
Python (pandas, matplotlib, seaborn), SQLite

## How to run
```bash
pip install -r ../requirements.txt
python analysis.py
```
Creates `data/clean/`, `images/`, `output/` (summary CSVs for Power BI / Tableau, `findings.json`, `sql_results.md`).

## Project structure
```
data/raw/     input CSV(s), unchanged
data/clean/   validated data with derived columns
sql/          queries.sql
images/       dashboard PNG
output/       summary CSVs, data_quality_audit.csv, findings.json, sql_results.md
analysis.py   validation, analysis, charts, SQL run
```

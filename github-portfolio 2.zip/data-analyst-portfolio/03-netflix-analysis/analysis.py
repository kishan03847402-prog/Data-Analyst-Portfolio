"""Project 3 - Netflix catalogue EDA: type/genre/country/rating mix, additions over time, data cleaning.
Input: data/raw/03_Netflix_Demo.csv"""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from common import *

here = setup(__file__)
raw = pd.read_csv(here / "data/raw/03_Netflix_Demo.csv", parse_dates=["DateAdded"])
a = Audit(here, len(raw)); df = raw.copy()
a.check("Duplicate ShowID", df.ShowID.duplicated(), "none found")
a.check("Missing values (any column)", df.isna().any(axis=1), "none found")
a.check("Repeated Title (same title, different ShowID/attributes)", df.Title.duplicated(), "kept - ShowID is the key; titles reused in this demo data, so title-level counts are NOT used")
df["DurationValue"] = df.Duration.str.extract(r"(\d+)").astype(int)
df["DurationUnit"] = np.where(df.Duration.str.contains("min"), "min", "Seasons")
conflict = ((df.Type == "Movie") & (df.DurationUnit == "Seasons")) | ((df.Type == "TV Show") & (df.DurationUnit == "min"))
a.check("Type/Duration conflict (Movie in 'Seasons' or TV Show in 'min')", conflict, "flagged; excluded ONLY from duration analysis")
df["DurationValid"] = ~conflict
a.check("Added to Netflix before its release year", df.DateAdded.dt.year < df.ReleaseYear, "kept; excluded from 'content age' calc")
a.save()

df["YearAdded"] = df.DateAdded.dt.year; df["MonthAdded"] = df.DateAdded.dt.to_period("M").dt.to_timestamp(); df["Quarter"] = df.DateAdded.dt.to_period("Q").astype(str)
df["ContentAge"] = (df.YearAdded - df.ReleaseYear).where(df.YearAdded >= df.ReleaseYear)
df["Decade"] = (df.ReleaseYear // 10 * 10).astype(str) + "s"
df.to_csv(here / "data/clean/netflix_clean.csv", index=False)

n = len(df)
type_mix = df.Type.value_counts(); genre = df.Genre.value_counts(); country = df.Country.value_counts(); rating = df.AgeRating.value_counts()
gt = pd.crosstab(df.Genre, df.Type); gt["Total"] = gt.sum(axis=1); gt = gt.sort_values("Total", ascending=False)
ct = pd.crosstab(df.Country, df.Genre)
ctn = ct.div(ct.sum(axis=1), axis=0) * 100
quarter = df.groupby(["Quarter", "Type"]).size().unstack(fill_value=0)
year = df.groupby("YearAdded").size()
dec = df.Decade.value_counts().sort_index()
valid = df[df.DurationValid]
mov = valid[valid.Type == "Movie"]; tv = valid[valid.Type == "TV Show"]
recent = (df.ReleaseYear >= 2015).mean() * 100
for nme, t in [("genre_by_type", gt), ("country_genre_pct", ctn.round(1)), ("added_by_quarter", quarter)]: t.to_csv(here / f"output/{nme}.csv")
top_pair = ct.stack().sort_values(ascending=False)
F = dict(rows=n, period_added=f"{df.DateAdded.min().date()} to {df.DateAdded.max().date()}", unique_titles=int(df.Title.nunique()),
         movies=int(type_mix["Movie"]), movies_pct=type_mix["Movie"] / n * 100, tv=int(type_mix["TV Show"]), tv_pct=type_mix["TV Show"] / n * 100,
         top_genre=genre.index[0], top_genre_pct=genre.iloc[0] / n * 100, low_genre=genre.index[-1], low_genre_pct=genre.iloc[-1] / n * 100,
         top_country=country.index[0], top_country_pct=country.iloc[0] / n * 100, top3_countries=list(country.index[:3]), top3_pct=country.iloc[:3].sum() / n * 100,
         top_rating=rating.index[0], top_rating_pct=rating.iloc[0] / n * 100, adult_rating_pct=(df.AgeRating == "A").mean() * 100,
         added_2024=int(year.get(2024, 0)), added_2025=int(year.get(2025, 0)), added_growth_pct=(year.get(2025, 0) / year.get(2024, 1) - 1) * 100,
         peak_quarter=quarter.sum(axis=1).idxmax(), peak_quarter_n=int(quarter.sum(axis=1).max()),
         median_content_age=df.ContentAge.median(), pct_released_2015_plus=recent, top_decade=dec.idxmax(),
         top_genre_country_pair=list(top_pair.index[0]), top_genre_country_n=int(top_pair.iloc[0]),
         movie_median_min=mov.DurationValue.median() if len(mov) else None, tv_avg_seasons=tv.DurationValue.mean() if len(tv) else None,
         conflict_rows=int(conflict.sum()), valid_duration_rows=int(df.DurationValid.sum()))
save_findings(here, F)

fig = plt.figure(figsize=(16, 10.5)); gs = fig.add_gridspec(2, 3, top=0.88, hspace=0.42, wspace=0.3)
header(fig, "Netflix Catalogue Analysis (Demo Dataset)", {"Titles (rows)": n, "Movies": f"{F['movies_pct']:.0f}%", "TV Shows": f"{F['tv_pct']:.0f}%", "Top genre": F["top_genre"], "Top country": F["top_country"]})
ax = fig.add_subplot(gs[0, 0]); ax.pie(type_mix, labels=type_mix.index, autopct="%1.0f%%", colors=[BLUE, ORANGE], startangle=90, wedgeprops=dict(width=.45)); ax.set_title("Movies vs TV Shows")
ax = fig.add_subplot(gs[0, 1]); gt[["Movie", "TV Show"]].plot.bar(stacked=True, ax=ax, color=[BLUE, ORANGE], rot=30); ax.set_title("Titles by Genre and Type"); ax.set_xlabel(""); ax.legend(frameon=False)
ax = fig.add_subplot(gs[0, 2]); country.sort_values().plot.barh(ax=ax, color=GREEN); ax.set_title("Titles by Country"); bar_labels(ax, "{:.0f}")
ax = fig.add_subplot(gs[1, 0]); quarter.plot.bar(stacked=True, ax=ax, color=[BLUE, ORANGE], rot=0); ax.set_title("Titles Added per Quarter"); ax.set_xlabel(""); ax.legend(frameon=False, fontsize=8)
ax = fig.add_subplot(gs[1, 1]); rating.plot.bar(ax=ax, color=PURPLE, rot=0); ax.set_title("Age Rating Mix"); bar_labels(ax, "{:.0f}")
ax = fig.add_subplot(gs[1, 2]); sns.heatmap(ctn, annot=True, fmt=".0f", cmap="YlGnBu", cbar=False, ax=ax); ax.set_title("Genre Mix by Country (% of country's titles)"); ax.set_xlabel(""); ax.set_ylabel(""); ax.tick_params(axis="x", rotation=40)
plt.savefig(here / "images/netflix_dashboard.png", dpi=150, bbox_inches="tight"); plt.close()
run_sql(here, {"titles": df})
print("\nFINDINGS"); [print(f"  {k}: {v}") for k, v in F.items()]; print(gt); print(quarter); print(rating); print(country)

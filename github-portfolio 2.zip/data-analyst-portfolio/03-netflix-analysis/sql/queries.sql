-- name: 1. Movies vs TV shows
SELECT Type, COUNT(*) AS titles, ROUND(100.0*COUNT(*)/(SELECT COUNT(*) FROM titles),1) AS share_pct FROM titles GROUP BY Type;

-- name: 2. Top genres with movie / TV split
SELECT Genre, COUNT(*) AS titles,
       SUM(CASE WHEN Type='Movie' THEN 1 ELSE 0 END) AS movies,
       SUM(CASE WHEN Type='TV Show' THEN 1 ELSE 0 END) AS tv_shows
FROM titles GROUP BY Genre ORDER BY titles DESC;

-- name: 3. Titles added per quarter
SELECT Quarter, COUNT(*) AS titles_added FROM titles GROUP BY Quarter ORDER BY Quarter;

-- name: 4. Top genre inside each country
SELECT Country, Genre, titles FROM (
  SELECT Country, Genre, COUNT(*) AS titles, ROW_NUMBER() OVER (PARTITION BY Country ORDER BY COUNT(*) DESC, Genre) AS rn
  FROM titles GROUP BY Country, Genre) WHERE rn = 1 ORDER BY titles DESC;

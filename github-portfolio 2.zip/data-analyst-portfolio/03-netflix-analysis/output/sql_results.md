### 1. Movies vs TV shows

```sql
SELECT Type, COUNT(*) AS titles, ROUND(100.0*COUNT(*)/(SELECT COUNT(*) FROM titles),1) AS share_pct FROM titles GROUP BY Type;
```

| Type    |   titles |   share_pct |
|:--------|---------:|------------:|
| Movie   |       83 |        46.1 |
| TV Show |       97 |        53.9 |

### 2. Top genres with movie / TV split

```sql
SELECT Genre, COUNT(*) AS titles,
       SUM(CASE WHEN Type='Movie' THEN 1 ELSE 0 END) AS movies,
       SUM(CASE WHEN Type='TV Show' THEN 1 ELSE 0 END) AS tv_shows
FROM titles GROUP BY Genre ORDER BY titles DESC;
```

| Genre       |   titles |   movies |   tv_shows |
|:------------|---------:|---------:|-----------:|
| Drama       |       33 |       12 |         21 |
| Comedy      |       29 |       16 |         13 |
| Thriller    |       26 |       17 |          9 |
| Romance     |       25 |       10 |         15 |
| Sci-Fi      |       24 |       10 |         14 |
| Documentary |       22 |       10 |         12 |
| Action      |       21 |        8 |         13 |

### 3. Titles added per quarter

```sql
SELECT Quarter, COUNT(*) AS titles_added FROM titles GROUP BY Quarter ORDER BY Quarter;
```

| Quarter   |   titles_added |
|:----------|---------------:|
| 2024Q1    |             22 |
| 2024Q2    |             15 |
| 2024Q3    |             22 |
| 2024Q4    |             25 |
| 2025Q1    |             26 |
| 2025Q2    |             20 |
| 2025Q3    |             26 |
| 2025Q4    |             24 |

### 4. Top genre inside each country

```sql
SELECT Country, Genre, titles FROM (
  SELECT Country, Genre, COUNT(*) AS titles, ROW_NUMBER() OVER (PARTITION BY Country ORDER BY COUNT(*) DESC, Genre) AS rn
  FROM titles GROUP BY Country, Genre) WHERE rn = 1 ORDER BY titles DESC;
```

| Country        | Genre    |   titles |
|:---------------|:---------|---------:|
| India          | Thriller |       10 |
| United Kingdom | Drama    |        8 |
| Canada         | Comedy   |        7 |
| South Korea    | Drama    |        7 |
| United States  | Drama    |        7 |
| Japan          | Action   |        5 |

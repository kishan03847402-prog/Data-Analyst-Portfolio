-- name: 1. Country comparison (average per record)
SELECT Country, COUNT(*) AS records, ROUND(AVG(NewCases),0) AS avg_cases, ROUND(AVG(NewDeaths),0) AS avg_deaths, ROUND(AVG(Vaccinations),0) AS avg_vaccinations
FROM covid GROUP BY Country ORDER BY avg_cases DESC;

-- name: 2. Test positivity by country (valid rows: cases <= tests)
SELECT Country, ROUND(100.0*SUM(NewCases)/SUM(Tests),1) AS positivity_pct
FROM covid WHERE NewCases <= Tests GROUP BY Country ORDER BY positivity_pct DESC;

-- name: 3. Monthly average cases with 3-month moving average
WITH m AS (SELECT substr(Date,1,7) AS month, AVG(NewCases) AS cases FROM covid GROUP BY 1)
SELECT month, ROUND(cases,0) AS avg_cases,
       ROUND(AVG(cases) OVER (ORDER BY month ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),0) AS moving_avg_3m
FROM m ORDER BY month;

-- name: 4. Yearly averages
SELECT substr(Date,1,4) AS year, COUNT(*) AS records, ROUND(AVG(NewCases),0) AS avg_cases, ROUND(AVG(Vaccinations),0) AS avg_vaccinations
FROM covid GROUP BY 1 ORDER BY 1;

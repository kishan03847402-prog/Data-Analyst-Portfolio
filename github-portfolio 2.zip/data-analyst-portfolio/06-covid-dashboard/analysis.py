"""Project 6 - COVID dashboard on a SYNTHETIC dataset: validation, monthly trends, country comparison, test positivity, vaccination.
Input: data/raw/06_COVID_Demo_Synthetic.csv (DataType column says 'Synthetic demonstration data').
This is a dashboard-building and data-validation exercise, NOT a statement about real COVID-19 numbers."""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from common import *

here = setup(__file__)
raw = pd.read_csv(here / "data/raw/06_COVID_Demo_Synthetic.csv", parse_dates=["Date"])
a = Audit(here, len(raw)); df = raw.copy()
a.check("Duplicate (Date, Country)", df.duplicated(["Date", "Country"]), "dropped duplicates (kept first)")
df = df.drop_duplicates(["Date", "Country"]).copy()
a.check("Missing values (any column)", df.isna().any(axis=1), "none found")
a.check("NewDeaths > NewCases (impossible)", df.NewDeaths > df.NewCases, "excluded from fatality-rate analysis")
a.check("NewCases > Tests (positivity > 100%, impossible)", df.NewCases > df.Tests, "excluded from positivity analysis")
a.check("Sparse sampling: ~7 rows per month across 8 countries (not daily data)", len(df), "no daily rolling averages; analysis uses monthly aggregates")
a.save()
df["PositivityValid"] = df.NewCases <= df.Tests; df["CFRValid"] = df.NewDeaths <= df.NewCases
df["Month"] = df.Date.dt.to_period("M").dt.to_timestamp(); df["Year"] = df.Date.dt.year
df["Positivity%"] = np.where(df.PositivityValid, df.NewCases / df.Tests * 100, np.nan)
df["CFR%"] = np.where(df.CFRValid, df.NewDeaths / df.NewCases * 100, np.nan)
df.to_csv(here / "data/clean/covid_clean.csv", index=False)

# country comparison on averages per record (records are samples, so totals would mislead)
ctry = df.groupby("Country").agg(Records=("Date", "size"), AvgCases=("NewCases", "mean"), AvgDeaths=("NewDeaths", "mean"), AvgTests=("Tests", "mean"), AvgVacc=("Vaccinations", "mean"))
v = df[df.CFRValid & df.PositivityValid]
ctry["Positivity%"] = df[df.PositivityValid].groupby("Country").apply(lambda g: g.NewCases.sum() / g.Tests.sum() * 100, include_groups=False)
ctry["CFR%"] = df[df.CFRValid].groupby("Country").apply(lambda g: g.NewDeaths.sum() / g.NewCases.sum() * 100, include_groups=False)
ctry["Vacc per case"] = ctry.AvgVacc / ctry.AvgCases
mon = df.groupby("Month").agg(Cases=("NewCases", "mean"), Deaths=("NewDeaths", "mean"), Vacc=("Vaccinations", "mean"), Records=("Date", "size"))
mon["Cases_3M_avg"] = mon.Cases.rolling(3, min_periods=2).mean()
yr = df.groupby("Year").agg(AvgCases=("NewCases", "mean"), AvgVacc=("Vaccinations", "mean"), AvgDeaths=("NewDeaths", "mean"))
ctry.round(2).to_csv(here / "output/country_summary.csv"); mon.round(1).to_csv(here / "output/monthly_summary.csv"); yr.round(1).to_csv(here / "output/yearly_summary.csv")
corr = df[["NewCases", "NewDeaths", "Tests", "Vaccinations"]].corr()
F = dict(rows_raw=len(raw), rows_clean=len(df), period=f"{df.Date.min().date()} to {df.Date.max().date()}", countries=int(df.Country.nunique()),
         avg_cases=df.NewCases.mean(), avg_deaths=df.NewDeaths.mean(), overall_positivity=df[df.PositivityValid].NewCases.sum() / df[df.PositivityValid].Tests.sum() * 100,
         overall_cfr=df[df.CFRValid].NewDeaths.sum() / df[df.CFRValid].NewCases.sum() * 100,
         top_cases_country=ctry.AvgCases.idxmax(), top_cases_v=ctry.AvgCases.max(), low_cases_country=ctry.AvgCases.idxmin(), low_cases_v=ctry.AvgCases.min(),
         top_pos_country=ctry["Positivity%"].idxmax(), top_pos_v=ctry["Positivity%"].max(), low_pos_country=ctry["Positivity%"].idxmin(), low_pos_v=ctry["Positivity%"].min(),
         top_cfr_country=ctry["CFR%"].idxmax(), top_cfr_v=ctry["CFR%"].max(), low_cfr_country=ctry["CFR%"].idxmin(), low_cfr_v=ctry["CFR%"].min(),
         top_vacc_country=ctry.AvgVacc.idxmax(), top_vacc_v=ctry.AvgVacc.max(), low_vacc_country=ctry.AvgVacc.idxmin(), low_vacc_v=ctry.AvgVacc.min(),
         peak_month=mon.Cases.idxmax().strftime("%b %Y"), peak_month_v=mon.Cases.max(), peak_month_records=int(mon.Records[mon.Cases.idxmax()]),
         yearly_avg_cases={int(k): round(x, 0) for k, x in yr.AvgCases.items()},
         corr_cases_deaths=corr.loc["NewCases", "NewDeaths"], corr_cases_tests=corr.loc["NewCases", "Tests"], corr_vacc_cases=corr.loc["Vaccinations", "NewCases"],
         invalid_cfr=int((~df.CFRValid).sum()), invalid_pos=int((~df.PositivityValid).sum()))
save_findings(here, F)

fig = plt.figure(figsize=(16, 10.5)); gs = fig.add_gridspec(2, 3, top=0.88, hspace=0.42, wspace=0.3)
header(fig, "COVID Dashboard (SYNTHETIC Demo Data)", {"Records": len(df), "Countries": F["countries"], "Avg daily-record cases": f"{F['avg_cases']:,.0f}", "Test positivity": f"{F['overall_positivity']:.1f}%"})
ax = fig.add_subplot(gs[0, :2]); ax.plot(mon.index, mon.Cases, color=BLUE, alpha=.45, marker="o", ms=3, label="Monthly mean of records"); ax.plot(mon.index, mon.Cases_3M_avg, color=RED, lw=2.5, label="3-month rolling average")
ax.set_title("Average New Cases per Record - Monthly Trend"); ax.legend(frameon=False)
ax = fig.add_subplot(gs[0, 2]); ctry.AvgCases.sort_values().plot.barh(ax=ax, color=BLUE); ax.set_title("Avg New Cases per Record by Country"); bar_labels(ax, "{:,.0f}")
ax = fig.add_subplot(gs[1, 0]); ctry["Positivity%"].sort_values().plot.barh(ax=ax, color=ORANGE); ax.set_title("Test Positivity % (valid rows)"); bar_labels(ax, "{:.1f}")
ax = fig.add_subplot(gs[1, 1]); ctry["CFR%"].sort_values().plot.barh(ax=ax, color=RED); ax.set_title("Case Fatality % (valid rows)"); bar_labels(ax, "{:.1f}")
ax = fig.add_subplot(gs[1, 2]); ctry.AvgVacc.sort_values().plot.barh(ax=ax, color=GREEN); ax.set_title("Avg Vaccinations per Record"); bar_labels(ax, "{:,.0f}")
fig.text(0.01, 0.005, "Synthetic data: shapes and rankings illustrate the dashboard design only and say nothing about the real pandemic.", fontsize=10, color=RED)
plt.savefig(here / "images/covid_dashboard.png", dpi=150, bbox_inches="tight"); plt.close()
run_sql(here, {"covid": df.drop(columns=["PositivityValid", "CFRValid"])})
print("\nFINDINGS"); [print(f"  {k}: {v}") for k, v in F.items()]; print(ctry.round(1)); print(mon.round(0).head(40))

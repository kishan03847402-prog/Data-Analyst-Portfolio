### 1. Country comparison (average per record)

```sql
SELECT Country, COUNT(*) AS records, ROUND(AVG(NewCases),0) AS avg_cases, ROUND(AVG(NewDeaths),0) AS avg_deaths, ROUND(AVG(Vaccinations),0) AS avg_vaccinations
FROM covid GROUP BY Country ORDER BY avg_cases DESC;
```

| Country        |   records |   avg_cases |   avg_deaths |   avg_vaccinations |
|:---------------|----------:|------------:|-------------:|-------------------:|
| Germany        |        38 |       25339 |          434 |             152207 |
| Brazil         |        25 |       23679 |          459 |             133024 |
| United States  |        31 |       23659 |          380 |             111785 |
| United Kingdom |        29 |       22969 |          389 |             121733 |
| South Africa   |        35 |       22877 |          416 |             126673 |
| Australia      |        20 |       21763 |          428 |             120515 |
| Japan          |        29 |       21641 |          408 |             110436 |
| India          |        31 |       19248 |          366 |             116638 |

### 2. Test positivity by country (valid rows: cases <= tests)

```sql
SELECT Country, ROUND(100.0*SUM(NewCases)/SUM(Tests),1) AS positivity_pct
FROM covid WHERE NewCases <= Tests GROUP BY Country ORDER BY positivity_pct DESC;
```

| Country        |   positivity_pct |
|:---------------|-----------------:|
| United Kingdom |             17   |
| Japan          |             15.3 |
| Germany        |             14.6 |
| South Africa   |             13.4 |
| Brazil         |             13.3 |
| United States  |             12.9 |
| Australia      |             12.5 |
| India          |             11.5 |

### 3. Monthly average cases with 3-month moving average

```sql
WITH m AS (SELECT substr(Date,1,7) AS month, AVG(NewCases) AS cases FROM covid GROUP BY 1)
SELECT month, ROUND(cases,0) AS avg_cases,
       ROUND(AVG(cases) OVER (ORDER BY month ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),0) AS moving_avg_3m
FROM m ORDER BY month;
```

| month   |   avg_cases |   moving_avg_3m |
|:--------|------------:|----------------:|
| 2020-03 |       28063 |           28063 |
| 2020-04 |       26763 |           27413 |
| 2020-05 |       10348 |           21724 |
| 2020-06 |       29527 |           22212 |
| 2020-07 |       14794 |           18223 |
| 2020-08 |       18553 |           20958 |
| 2020-09 |       25548 |           19631 |
| 2020-10 |       16435 |           20179 |
| 2020-11 |       27306 |           23096 |
| 2020-12 |       22915 |           22218 |
| 2021-01 |       23971 |           24731 |
| 2021-02 |       24964 |           23950 |
| 2021-03 |       23283 |           24073 |
| 2021-04 |       23833 |           24027 |
| 2021-05 |       15542 |           20886 |
| 2021-06 |       32387 |           23921 |
| 2021-07 |       26741 |           24890 |
| 2021-08 |       23262 |           27463 |
| 2021-09 |       19501 |           23168 |
| 2021-10 |       18602 |           20455 |
| 2021-11 |       28477 |           22193 |
| 2021-12 |       15546 |           20875 |
| 2022-01 |       14869 |           19631 |
| 2022-02 |       25285 |           18567 |
| 2022-03 |       20926 |           20360 |
| 2022-04 |       22845 |           23019 |
| 2022-05 |       20326 |           21366 |
| 2022-06 |       24118 |           22430 |
| 2022-07 |       18741 |           21062 |
| 2022-08 |       13036 |           18632 |
| 2022-09 |       15743 |           15840 |
| 2022-10 |       40231 |           23003 |
| 2022-11 |       30145 |           28706 |
| 2022-12 |       24760 |           31712 |

### 4. Yearly averages

```sql
SELECT substr(Date,1,4) AS year, COUNT(*) AS records, ROUND(AVG(NewCases),0) AS avg_cases, ROUND(AVG(Vaccinations),0) AS avg_vaccinations
FROM covid GROUP BY 1 ORDER BY 1;
```

|   year |   records |   avg_cases |   avg_vaccinations |
|-------:|----------:|------------:|-------------------:|
|   2020 |        58 |       22939 |             133532 |
|   2021 |        90 |       23517 |             127637 |
|   2022 |        90 |       21863 |             117057 |

# COVID-19 Dashboard on Synthetic Data: Validation and Visual Design

A country-comparison dashboard with positivity, fatality and vaccination metrics, built on synthetic data with validation rules.

> **Dataset note:** this project uses a *demo / synthetic* dataset supplied for portfolio practice. All numbers below describe that file, not a real company or event. The code is schema-compatible: drop a real CSV with the same columns into `data/raw/` and re-run.

![dashboard](images/covid_dashboard.png)

## Problem statement
Public-health stakeholders need a compact view comparing countries on cases, test positivity, fatality and vaccination.

## Dataset
| | |
|---|---|
| File | `data/raw/06_COVID_Demo_Synthetic.csv` |
| Size | 240 rows |
| Period | 2020-03-01 to 2022-12-31 |
| Columns | Date, Country, NewCases, NewDeaths, Tests, Vaccinations, DataType |

## Business questions
- How do countries compare on cases, positivity, fatality and vaccinations?
- How do cases evolve over time?
- Which records are logically impossible and must be excluded?

## Approach
1. Removed duplicate (date, country) rows; excluded impossible records from the affected ratios only.
2. Used monthly aggregates and a 3-month rolling average because records are sparse (about 7 per month across 8 countries), not daily.
3. Built the dashboard so it can be pointed at a real daily dataset.

## Data quality audit
Every check is run by `analysis.py` and saved to `output/data_quality_audit.csv`.

| Check                                                                  |   Rows affected |   % of rows | Action taken                                                |
|:-----------------------------------------------------------------------|----------------:|------------:|:------------------------------------------------------------|
| Duplicate (Date, Country)                                              |               2 |         0.8 | dropped duplicates (kept first)                             |
| Missing values (any column)                                            |               0 |         0   | none found                                                  |
| NewDeaths > NewCases (impossible)                                      |               4 |         1.7 | excluded from fatality-rate analysis                        |
| NewCases > Tests (positivity > 100%, impossible)                       |              16 |         6.7 | excluded from positivity analysis                           |
| Sparse sampling: ~7 rows per month across 8 countries (not daily data) |             238 |        99.2 | no daily rolling averages; analysis uses monthly aggregates |

## Key findings
1. The file is labelled 'Synthetic demonstration data': these results describe the dashboard, not the real pandemic.
2. Validation caught 16 records with more cases than tests (positivity above 100%) and 4 with more deaths than cases, plus 2 duplicates (240 to 238 rows).
3. Pooled test positivity is 13.8% and case fatality 1.76%. Country ranges are narrow: positivity 11.5% (India) to 17.0% (United Kingdom); fatality 1.6% to 2.0%.
4. Average cases per record: Germany highest (25,338), India lowest (19,248). Yearly averages are flat (2020: 22,939; 2021: 23,517; 2022: 21,863).
5. Cases and deaths are not correlated (r = -0.10) and neither are cases and tests (r = -0.03). Real outbreak data would show positive links, which confirms the data is random. The apparent peak in Oct 2022 rests on only 2 records.

## Recommendations
1. Keep the validation rules (cases <= tests, deaths <= cases, unique date-country) as the first step for any real COVID dataset.
2. Re-run with a daily public dataset to enable 7-day rolling averages, per-million normalisation and waves analysis.
3. Never rank countries on sparse samples: the Oct 2022 'peak' is a 2-record artefact.

## Limitations
- Synthetic data: no real-world conclusions may be drawn.
- No population column, so per-capita rates are not possible.
- Records are not daily, so true rolling averages are not computed.

## SQL
`sql/queries.sql` re-computes the key metrics in SQL (SQLite syntax, window functions). `analysis.py` executes them and writes the results to [`output/sql_results.md`](output/sql_results.md), so the SQL is tested, not just written.

## Tools
Python (pandas, matplotlib, seaborn), SQLite (moving-average window), Power BI ready CSVs

## How to run
```bash
pip install -r ../requirements.txt
python analysis.py
```
Creates `data/clean/`, `images/`, `output/` (summary CSVs for Power BI / Tableau, `findings.json`, `sql_results.md`).

## Project structure
```
data/raw/     input CSV(s), unchanged
data/clean/   validated data with derived columns
sql/          queries.sql
images/       dashboard PNG
output/       summary CSVs, data_quality_audit.csv, findings.json, sql_results.md
analysis.py   validation, analysis, charts, SQL run
```

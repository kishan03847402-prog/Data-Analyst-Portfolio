### 1. Overall KPIs

```sql
SELECT COUNT(DISTINCT OrderID) AS orders, ROUND(SUM(Revenue),0) AS revenue, ROUND(SUM(Profit),0) AS profit,
       ROUND(100.0*SUM(Profit)/SUM(Revenue),1) AS margin_pct, ROUND(SUM(Revenue)/COUNT(DISTINCT OrderID),0) AS aov
FROM sales;
```

|   orders |   revenue |   profit |   margin_pct |   aov |
|---------:|----------:|---------:|-------------:|------:|
|      300 |    377880 |   121952 |         32.3 |  1259 |

### 2. Monthly revenue with month-over-month growth

```sql
WITH m AS (
  SELECT substr(OrderDate,1,7) AS month, SUM(Revenue) AS revenue FROM sales GROUP BY 1)
SELECT month, ROUND(revenue,0) AS revenue,
       ROUND(100.0*(revenue - LAG(revenue) OVER (ORDER BY month)) / LAG(revenue) OVER (ORDER BY month),1) AS mom_growth_pct
FROM m ORDER BY month;
```

| month   |   revenue |   mom_growth_pct |
|:--------|----------:|-----------------:|
| 2025-01 |     64900 |            nan   |
| 2025-02 |     48230 |            -25.7 |
| 2025-03 |     74755 |             55   |
| 2025-04 |     55725 |            -25.5 |
| 2025-05 |     86920 |             56   |
| 2025-06 |     47350 |            -45.5 |

### 3. Region ranking by revenue share and margin

```sql
SELECT Region, ROUND(SUM(Revenue),0) AS revenue,
       ROUND(100.0*SUM(Revenue)/(SELECT SUM(Revenue) FROM sales),1) AS revenue_share_pct,
       ROUND(100.0*SUM(Profit)/SUM(Revenue),1) AS margin_pct,
       RANK() OVER (ORDER BY SUM(Revenue) DESC) AS rev_rank
FROM sales GROUP BY Region;
```

| Region   |   revenue |   revenue_share_pct |   margin_pct |   rev_rank |
|:---------|----------:|--------------------:|-------------:|-----------:|
| Central  |     91330 |                24.2 |         31.3 |          1 |
| North    |     90720 |                24   |         31.7 |          2 |
| West     |     78060 |                20.7 |         34   |          3 |
| East     |     67740 |                17.9 |         33   |          4 |
| South    |     50030 |                13.2 |         31.3 |          5 |

### 4. Best product in each region by profit

```sql
SELECT Region, Product, profit FROM (
  SELECT Region, Product, ROUND(SUM(Profit),0) AS profit,
         ROW_NUMBER() OVER (PARTITION BY Region ORDER BY SUM(Profit) DESC) AS rn
  FROM sales GROUP BY Region, Product) WHERE rn = 1 ORDER BY profit DESC;
```

| Region   | Product   |   profit |
|:---------|:----------|---------:|
| Central  | Laptop    |     8177 |
| East     | Printer   |     6964 |
| North    | Keyboard  |     6300 |
| West     | Laptop    |     4973 |
| South    | Mouse     |     4052 |

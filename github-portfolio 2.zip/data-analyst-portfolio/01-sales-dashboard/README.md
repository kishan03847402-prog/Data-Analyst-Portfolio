# Sales Performance Dashboard

Where do revenue and profit come from, and which months, regions and products need attention?

> **Dataset note:** this project uses a *demo / synthetic* dataset supplied for portfolio practice. All numbers below describe that file, not a real company or event. The code is schema-compatible: drop a real CSV with the same columns into `data/raw/` and re-run.

![dashboard](images/sales_dashboard.png)

## Problem statement
Management needs one view of revenue, profit and growth to decide where to focus sales effort.

## Dataset
| | |
|---|---|
| File | `data/raw/01_Sales_Demo.csv` |
| Size | 300 rows |
| Period | 2025-01-02 to 2025-06-29 |
| Columns | OrderID, OrderDate, Product, Region, Quantity, UnitPrice, Revenue, Cost, Profit |

## Business questions
- What are total revenue, profit, margin, orders and average order value (AOV)?
- How do revenue and profit move month over month?
- Which regions and products drive revenue and profit?

## Approach
1. Validated revenue = quantity x price and profit = revenue - cost on every row.
2. Built monthly KPI table with MoM growth, region and product summaries, and a region x product profit matrix.
3. Re-checked every KPI with SQL (window functions: LAG, RANK, ROW_NUMBER).

## Data quality audit
Every check is run by `analysis.py` and saved to `output/data_quality_audit.csv`.

| Check                                                   |   Rows affected |   % of rows | Action taken                                       |
|:--------------------------------------------------------|----------------:|------------:|:---------------------------------------------------|
| Duplicate OrderID                                       |               0 |         0   | none found - kept all                              |
| Missing values (any column)                             |               0 |         0   | none found                                         |
| Revenue != Quantity x UnitPrice                         |               0 |         0   | none found                                         |
| Profit != Revenue - Cost                                |               0 |         0   | none found                                         |
| Negative profit orders                                  |               0 |         0   | kept (valid business loss)                         |
| Products sold at >1 unit price (price varies per order) |               8 |         2.7 | kept; analysed at product level, not by price list |

## Key findings
1. Revenue 377,880 and profit 121,952 on 300 orders: a 32.3% margin and AOV of 1,260.
2. Revenue is volatile: May 2025 was the best month (86,920) and Jun 2025 the weakest (47,350), with MoM swings between -46% and +56%. Q2 revenue was only 1.1% above Q1.
3. Revenue follows order count (35-65 orders a month), not basket size: AOV stayed in a narrow 1,150-1,380 band.
4. Central (24.2%) and North (24.0%) generate almost half of revenue; South is smallest at 13.2%. West has the best margin (34.0%), Central and South the lowest (31.3%).
5. Printer and Laptop together bring 32.2% of revenue. Mouse has the best margin (35.9%); Phone (29.2%) and Monitor (29.6%) the lowest.

## Recommendations
1. Review pricing/cost on Phone and Monitor: they sell well but keep the thinnest margins (about 29-30%).
2. Because revenue tracks order volume, plan promotions for the historically weak months (Feb, Apr, Jun) instead of pushing AOV.
3. Diagnose South before investing: it has the smallest share (13%) and a below-average margin.

## Limitations
- Only Jan-Jun 2025 exists, so year-over-year growth cannot be computed; trends are 6 data points.
- Unit price varies from order to order for the same product, so results are at product level, not price-list level.
- Currency is not specified in the file; values are shown without a currency symbol.

## SQL
`sql/queries.sql` re-computes the key metrics in SQL (SQLite syntax, window functions). `analysis.py` executes them and writes the results to [`output/sql_results.md`](output/sql_results.md), so the SQL is tested, not just written.

## Tools
Python (pandas, matplotlib, seaborn), SQLite, Power BI / Tableau ready CSVs

## How to run
```bash
pip install -r ../requirements.txt
python analysis.py
```
Creates `data/clean/`, `images/`, `output/` (summary CSVs for Power BI / Tableau, `findings.json`, `sql_results.md`).

## Project structure
```
data/raw/     input CSV(s), unchanged
data/clean/   validated data with derived columns
sql/          queries.sql
images/       dashboard PNG
output/       summary CSVs, data_quality_audit.csv, findings.json, sql_results.md
analysis.py   validation, analysis, charts, SQL run
```

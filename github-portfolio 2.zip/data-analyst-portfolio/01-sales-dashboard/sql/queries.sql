-- name: 1. Overall KPIs
SELECT COUNT(DISTINCT OrderID) AS orders, ROUND(SUM(Revenue),0) AS revenue, ROUND(SUM(Profit),0) AS profit,
       ROUND(100.0*SUM(Profit)/SUM(Revenue),1) AS margin_pct, ROUND(SUM(Revenue)/COUNT(DISTINCT OrderID),0) AS aov
FROM sales;

-- name: 2. Monthly revenue with month-over-month growth
WITH m AS (
  SELECT substr(OrderDate,1,7) AS month, SUM(Revenue) AS revenue FROM sales GROUP BY 1)
SELECT month, ROUND(revenue,0) AS revenue,
       ROUND(100.0*(revenue - LAG(revenue) OVER (ORDER BY month)) / LAG(revenue) OVER (ORDER BY month),1) AS mom_growth_pct
FROM m ORDER BY month;

-- name: 3. Region ranking by revenue share and margin
SELECT Region, ROUND(SUM(Revenue),0) AS revenue,
       ROUND(100.0*SUM(Revenue)/(SELECT SUM(Revenue) FROM sales),1) AS revenue_share_pct,
       ROUND(100.0*SUM(Profit)/SUM(Revenue),1) AS margin_pct,
       RANK() OVER (ORDER BY SUM(Revenue) DESC) AS rev_rank
FROM sales GROUP BY Region;

-- name: 4. Best product in each region by profit
SELECT Region, Product, profit FROM (
  SELECT Region, Product, ROUND(SUM(Profit),0) AS profit,
         ROW_NUMBER() OVER (PARTITION BY Region ORDER BY SUM(Profit) DESC) AS rn
  FROM sales GROUP BY Region, Product) WHERE rn = 1 ORDER BY profit DESC;

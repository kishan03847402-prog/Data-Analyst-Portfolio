"""Project 1 - Sales Dashboard: KPIs, monthly trend, region x product performance.
Input : data/raw/01_Sales_Demo.csv   Output: data/clean, images/, output/, sql_results.md"""
import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from common import *

here = setup(__file__)
raw = pd.read_csv(here / "data/raw/01_Sales_Demo.csv", parse_dates=["OrderDate"])
a = Audit(here, len(raw))

# ---------- 1. Validate
df = raw.copy()
a.check("Duplicate OrderID", df.OrderID.duplicated(), "none found - kept all")
a.check("Missing values (any column)", df.isna().any(axis=1), "none found")
a.check("Revenue != Quantity x UnitPrice", (df.Revenue - df.Quantity * df.UnitPrice).abs() > 0.01, "none found")
a.check("Profit != Revenue - Cost", (df.Profit - (df.Revenue - df.Cost)).abs() > 0.01, "none found")
a.check("Negative profit orders", df.Profit < 0, "kept (valid business loss)")
pp = df.groupby("Product").UnitPrice.nunique()
a.check("Products sold at >1 unit price (price varies per order)", pp.gt(1).sum(), "kept; analysed at product level, not by price list")
a.save()

# ---------- 2. Features
df["Month"] = df.OrderDate.dt.to_period("M").dt.to_timestamp()
df["Margin%"] = df.Profit / df.Revenue * 100
df.to_csv(here / "data/clean/sales_clean.csv", index=False)

# ---------- 3. KPIs
rev, prof, orders = df.Revenue.sum(), df.Profit.sum(), df.OrderID.nunique()
monthly = df.groupby("Month").agg(Revenue=("Revenue", "sum"), Profit=("Profit", "sum"), Orders=("OrderID", "nunique"), Units=("Quantity", "sum"))
monthly["Margin%"] = monthly.Profit / monthly.Revenue * 100
monthly["AOV"] = monthly.Revenue / monthly.Orders
monthly["MoM_Revenue%"] = monthly.Revenue.pct_change() * 100
region = df.groupby("Region").agg(Revenue=("Revenue", "sum"), Profit=("Profit", "sum"), Orders=("OrderID", "count")).sort_values("Revenue", ascending=False)
region["Share%"] = region.Revenue / rev * 100; region["Margin%"] = region.Profit / region.Revenue * 100
product = df.groupby("Product").agg(Revenue=("Revenue", "sum"), Profit=("Profit", "sum"), Units=("Quantity", "sum"), Orders=("OrderID", "count")).sort_values("Revenue", ascending=False)
product["Share%"] = product.Revenue / rev * 100; product["Margin%"] = product.Profit / product.Revenue * 100
rp = df.pivot_table(index="Region", columns="Product", values="Profit", aggfunc="sum")
for n, t in [("kpi_monthly", monthly), ("region_summary", region), ("product_summary", product), ("region_product_profit", rp)]:
    t.round(2).to_csv(here / f"output/{n}.csv")

# first-half vs second-half momentum (only Jan-Jun 2025 exists, so no YoY)
h1, h2 = monthly.Revenue.iloc[:3].sum(), monthly.Revenue.iloc[3:].sum()
top2 = product.Revenue.head(2).sum() / rev * 100
F = dict(rows=len(df), period=f"{df.OrderDate.min().date()} to {df.OrderDate.max().date()}", revenue=rev, profit=prof, margin_pct=prof / rev * 100,
         orders=orders, aov=rev / orders, units=int(df.Quantity.sum()),
         best_month=monthly.Revenue.idxmax().strftime("%b %Y"), best_month_rev=monthly.Revenue.max(),
         worst_month=monthly.Revenue.idxmin().strftime("%b %Y"), worst_month_rev=monthly.Revenue.min(),
         q1_rev=h1, q2_rev=h2, q2_vs_q1_pct=(h2 / h1 - 1) * 100,
         top_region=region.index[0], top_region_share=region["Share%"].iloc[0], low_region=region.index[-1], low_region_share=region["Share%"].iloc[-1],
         region_margin_best=region["Margin%"].idxmax(), region_margin_best_v=region["Margin%"].max(), region_margin_worst=region["Margin%"].idxmin(), region_margin_worst_v=region["Margin%"].min(),
         top_product=product.index[0], top_product_share=product["Share%"].iloc[0], top2_products=list(product.index[:2]), top2_share=top2,
         best_margin_product=product["Margin%"].idxmax(), best_margin_v=product["Margin%"].max(), worst_margin_product=product["Margin%"].idxmin(), worst_margin_v=product["Margin%"].min(),
         top_profit_product=product.Profit.idxmax(), top_profit_product_share=product.Profit.max() / prof * 100,
         loss_orders=int((df.Profit < 0).sum()))
save_findings(here, F)

# ---------- 4. Dashboard
fig = plt.figure(figsize=(16, 10.5)); gs = fig.add_gridspec(2, 3, top=0.88, hspace=0.38, wspace=0.28)
header(fig, "Sales Dashboard (Demo Dataset, Jan-Jun 2025)", {"Revenue": f"{rev/1e6:.2f}M", "Profit": f"{prof/1e6:.2f}M", "Margin": f"{prof/rev*100:.1f}%", "Orders": f"{orders}", "AOV": f"{rev/orders:,.0f}"})
ax = fig.add_subplot(gs[0, :2]); x = monthly.index.strftime("%b")
ax.plot(x, monthly.Revenue / 1e3, marker="o", color=BLUE, lw=2.5, label="Revenue"); ax.plot(x, monthly.Profit / 1e3, marker="o", color=GREEN, lw=2.5, label="Profit")
ax.set_title("Monthly Revenue and Profit (thousands)"); ax.legend(frameon=False); ax.set_ylim(0)
for i, v in enumerate(monthly.Revenue / 1e3): ax.annotate(f"{v:,.0f}", (i, v), textcoords="offset points", xytext=(0, 7), ha="center", fontsize=9)
ax = fig.add_subplot(gs[0, 2]); (region.Revenue / 1e3).plot.bar(ax=ax, color=BLUE, rot=0); ax.set_title("Revenue by Region (thousands)"); bar_labels(ax)
ax = fig.add_subplot(gs[1, 0]); (product.Profit / 1e3).sort_values().plot.barh(ax=ax, color=GREEN); ax.set_title("Profit by Product (thousands)"); bar_labels(ax, "{:,.0f}")
ax = fig.add_subplot(gs[1, 1]); product["Margin%"].sort_values().plot.barh(ax=ax, color=ORANGE); ax.set_title("Profit Margin % by Product"); bar_labels(ax, "{:.1f}")
ax = fig.add_subplot(gs[1, 2]); sns.heatmap(rp / 1e3, annot=True, fmt=".0f", cmap="Blues", cbar=False, ax=ax); ax.set_title("Profit: Region x Product (thousands)"); ax.set_xlabel(""); ax.set_ylabel(""); ax.tick_params(axis="x", rotation=60)
plt.savefig(here / "images/sales_dashboard.png", dpi=150, bbox_inches="tight"); plt.close()

run_sql(here, {"sales": df})
print("\nFINDINGS"); [print(f"  {k}: {v}") for k, v in F.items()]
print(monthly.round(1)); print(region.round(1)); print(product.round(1))

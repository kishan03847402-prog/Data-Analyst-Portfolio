"""Shared helpers for all projects: paths, plotting style, data-quality audit log."""
import json, pathlib
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

BLUE, GREEN, ORANGE, RED, GREY, PURPLE = "#3b6fb6", "#4c9f70", "#e39a3b", "#d1495b", "#8d99ae", "#7a5195"

def setup(project_file):
    """Return (project_dir, style-applied) and make sure output folders exist."""
    here = pathlib.Path(project_file).resolve().parent
    for d in ("data/clean", "images", "output"):
        (here / d).mkdir(parents=True, exist_ok=True)
    sns.set_theme(style="whitegrid", context="notebook")
    plt.rcParams.update({"axes.titleweight": "bold", "axes.titlesize": 12, "figure.dpi": 100,
                         "axes.spines.top": False, "axes.spines.right": False})
    return here

class Audit:
    """Collects every data-quality check so the README can show what was found and what was done."""
    def __init__(self, here, n_rows):
        self.here, self.n, self.rows = here, n_rows, []
    def check(self, name, mask_or_count, action):
        cnt = int(mask_or_count.sum()) if hasattr(mask_or_count, "sum") else int(mask_or_count)
        self.rows.append({"check": name, "rows_affected": cnt, "pct_of_rows": round(cnt / self.n * 100, 1), "action": action})
        return cnt
    def save(self):
        df = pd.DataFrame(self.rows)
        df.to_csv(self.here / "output" / "data_quality_audit.csv", index=False)
        print("\nDATA QUALITY AUDIT"); print(df.to_string(index=False))
        return df

def save_findings(here, d):
    def conv(o):
        if isinstance(o, (np.integer,)): return int(o)
        if isinstance(o, (np.floating,)): return float(o)
        if isinstance(o, (pd.Timestamp,)): return str(o.date())
        return str(o)
    (here / "output" / "findings.json").write_text(json.dumps(d, indent=2, default=conv))

def pct(a, b): return float(a) / float(b) * 100 if b else float("nan")

def bar_labels(ax, fmt="{:,.0f}", horizontal=False, size=9):
    for c in ax.containers:
        ax.bar_label(c, fmt=lambda v: fmt.format(v), fontsize=size, padding=2)

def header(fig, title, kpis):
    fig.suptitle(title, fontsize=17, fontweight="bold", x=0.01, ha="left", y=0.995)
    fig.text(0.01, 0.945, "   |   ".join(f"{k}: {v}" for k, v in kpis.items()), fontsize=11.5, color="#444", ha="left")

def run_sql(here, tables):
    """Load cleaned DataFrames into in-memory SQLite and run sql/queries.sql.
    Queries are separated by lines starting with '-- name:'. Results go to output/sql_results.md."""
    import sqlite3
    con = sqlite3.connect(":memory:")
    for name, df in tables.items():
        d = df.copy()
        for c in d.columns:
            if str(d[c].dtype).startswith("datetime"): d[c] = d[c].dt.strftime("%Y-%m-%d")
        d.to_sql(name, con, index=False)
    text = (here / "sql" / "queries.sql").read_text()
    blocks = [b for b in text.split("-- name:") if b.strip()]
    out = []
    for b in blocks:
        name, _, q = b.partition("\n")
        res = pd.read_sql_query(q.strip().rstrip(";"), con)
        out.append(f"### {name.strip()}\n\n```sql\n{q.strip()}\n```\n\n{res.to_markdown(index=False)}\n")
    (here / "output" / "sql_results.md").write_text("\n".join(out))
    con.close()
    print(f"SQL: ran {len(blocks)} queries OK")

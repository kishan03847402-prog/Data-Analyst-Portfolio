"""Run every project: python run_all.py"""
import subprocess, sys, pathlib
root = pathlib.Path(__file__).parent
for d in sorted(p for p in root.iterdir() if p.is_dir() and p.name[:2].isdigit()):
    print(f"\n=== {d.name} ===")
    subprocess.run([sys.executable, "analysis.py"], cwd=d, check=True, stdout=subprocess.DEVNULL)
print("\nAll projects rebuilt.")
